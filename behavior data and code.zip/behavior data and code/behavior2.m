%% code for behavior 2
%% 这个是第二实验的行为数据分析
clc;
clear;
all_acc2 = [];
for p =1 : 33
    fileName1 = ['/home/lcy/MEG_attention/record/attention1sub', num2str(p,'%02d'),'_05.mat'];    
    %% load('B:\MEG_code\LCY\record\attention1sub02_05.mat')
    load(fileName1);
    result1 = result;
    fileName2 = ['/home/lcy/MEG_attention/record/attention1sub', num2str(p,'%02d'),'_06.mat']; 
    load(fileName2);
    result2 = result;
    data = zeros(2,100);
    a ={'trail','type1','type2','type3','response'};
     for i=1:50
             data(1,i) = result1(i).type2;
             data(2,i) = result1(i).response;
     end
      for i=51:100
             data(1,i) = result2(i-50).type2;
             data(2,i) = result2(i-50).response;
      end
      acc=0;
     for i =1:100
         a1= data(1,i);
         a2 = data(2,i);
         if a1 == 0 && a2 == 2
             acc_num =1;
         elseif a1 == 1 && a2 ==1
             acc_num = 1;
         else
             acc_num = 0;        
         end
         acc = acc+acc_num;
     end 
 all_acc2(p)  = acc;   
end