%% code for attention behavior （实验一的行为数据分析）
%% 这个code 是分析四种条件下的按键情况的准确率
clc;
clear;
location1 = cell(1,4);
location2 = cell(1,4);
location3 = cell(1,4);
location4 = cell(1,4);
acc = cell(1,4);
%%
all_acc = [];
for q =1 :  33
%Filename = []
    for n =1 :4
        fileName = ['/home/lcy/MEG_attention/record/attentionsub', num2str(q,'%02d'),'_',num2str(n,'%02d'),'.mat'];    
        load(fileName);
        result = result;
     %% extract behavior data
        data = zeros(5,100);
        a ={'trail','type1','type2','type3','response'};
         for i=1:100
             data(1,i) = result(i).trail;
             data(2,i) = result(i).type1;
             data(3,i) = result(i).type2;
             data(4,i) = result(i).type3;
             data(5,i) = result(i).response;
         end
     %% class the behavior data attention1 ,attention2,attention3,attention4;
        attention1 = [];
        attention2 = [];
        attention3 = [];
        attention4 = [];
        for i = 1:100
            a = data(2,i);
            att1=[];
            att2=[];
            att3=[];
            att4=[];
            if a == 1
                att1 = data(:,i);
                attention1 =[attention1;att1'];
            elseif a == 2
                att2 = data(:,i);
                attention2 =[attention2;att2'];
            elseif a == 3
                att3 = data(:,i);
                attention3 =[attention3;att3'];
            elseif a==4
                att4 = data(:,i);
                attention4 =[attention4;att4'];
            end
        end 
     %% done, reset the order of each control data
        for p = 1:25
            attention1(p,1) = p;
            attention2(p,1) = p;
            attention3(p,1) = p;
            attention4(p,1) = p;
            attention5(p,1) = p;
        end
     %% accuracy for press and return the unpress index
        acc1 = 0;
        acc2 = 0;
        acc3 = 0;
        acc4 = 0;
        index1=[];
        index2 = [];
        index3 = [];
        index4 = [];
        for i = 1:25
            a1 = attention1(i,3);
            a2 = attention1(i,5);
            if a1 == 0 && a2 == 2
                acc1_num = 1;
            else 
                acc1_num= 0;
            end
            if a1 == 1
                index1(i) = attention1(i,1);
            else
                index1(i) = 0;
            end
            acc1 = acc1+acc1_num;    
     %%
            b1 = attention2(i,3);
            b2 = attention2(i,5);
            if b1 == 0 & b2 == 1
                acc2_num = 1;
            else 
                acc2_num= 0;
            end
            if b1 == 1
                index2(i) = attention2(i,1) ;
            else
                index2(i) = 0;
            end
            acc2 = acc2+acc2_num 
     %%
            c1 = attention3(i,3);
            c2 = attention3(i,5);
            if c1 == 0 & c2 == 2
                acc3_num = 1;
            else 
                acc3_num= 0;
            end
            if c1 ==1
                index3(i) = attention3(i,1);
            else
                index3(i) = 0;
            end
            acc3 = acc3+acc3_num 
     %%
            d1 = attention4(i,3);
            d2 = attention4(i,5);
            if d1 == 0 & d2 == 1
                acc4_num = 1;
            else 
                acc4_num= 0;
            end
            if d1 ==1
                index4(i) = attention4(i,1)
            else
                index4(i)= 0;
            end
            acc4 = acc4+acc4_num 
        end
     %% location index for non-press
        acc{1,n} = acc1+acc2+acc3+acc4;
        location1{1,n} = find(index1 ~=0);
        location2{1,n} = find(index2 ~=0);
        location3{1,n} = find(index3 ~=0);
        location4{1,n}= find(index4 ~=0);
    %%
    end
    %% accuracy for four run
    acc1 =[];
    accuracy =[];
    for i = 1:4
        b= acc{1,i};
        accuracy(i) = b;
    end
    acc1 = sum(accuracy)/32;
    fileName1 = ['/home/lcy/MEG_attention/record/sub', num2str(q,'%02d'),'_att1.mat'];  
    fileName2 = ['/home/lcy/MEG_attention/record/sub', num2str(q,'%02d'),'_att2.mat'];  
    fileName3 = ['/home/lcy/MEG_attention/record/sub', num2str(q,'%02d'),'_att3.mat'];  
    fileName4 = ['/home/lcy/MEG_attention/record/sub', num2str(q,'%02d'),'_att4.mat'];  
    save(fileName1,'location1');
    save(fileName2,'location2');
    save(fileName3,'location3');
    save(fileName4,'location4');
%%
all_acc(q) = acc1;
end
%save('/home/lcy/MEG_attention/record/sub01_acc1.mat','acc');

