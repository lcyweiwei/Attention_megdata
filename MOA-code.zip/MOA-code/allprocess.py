#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 29 16:03:44 2022

@author: lcy
"""
###  processoring data  code for all subject 
## name for subject sub01 huang_zheng, sub02 bi_keyan, sub03 yao_jingyang, sub04 li_shuangyu, sub05 liang_yimei, sub06 qiu_shihan
# sub07 li_yihan sub08 li_xinyang sub09 ji_youting sub10 sha_jingjing, sub11 zheng_yi, sub12 jin_meizi, sub13 zhu_xinyi sub14 pan_ningxin,
# sub15 zhang_zhengnan, sub16 ni_can, sub17 tang_yushun, sub18 yin_zhiyuan, sub19 deji_yangla sub 20 liang_shuyu, sub21 liu_chewei, sub 22 wang_siqi
# sub23 sun_yingning sub24 guo_yang sub25 zuoteng_jizi sub26 chen_wangnan sub27 cheng_jianxin sub28 meng_ruishuang sub29 zhang_yidan(cha)
# sub 30 xu_fangliang sub31 qiao_shan, sub32 wang_mo, sub33 yang_jing
import os
import numpy as np
import mne
from copy import deepcopy
import matplotlib.pyplot as plt
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
## classifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
##  from sklearn to mne
from mne.decoding import (SlidingEstimator, GeneralizingEstimator, Scaler, cross_val_multiscore, LinearModel, 
                          get_coef, Vectorizer, CSP)
## in order to analysis
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/yao_jingyang/220622/' ## sub 03
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/li_shuangyu/220622/' ## sub 04
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/liang_yimei/220622/' ## sub 05
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/qiu_shihan/220622/' ## sub 06
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/li_yihan/220622/' ## sub 07
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/li_xinyang/220623/' ## sub 08
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/ji_youting/220623/' ## sub 09
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/sha_jingjing/220623/' ## sub 10
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/zheng_yi/220623/' ## sub 11
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/jin_meizi/220623/' ## sub 12
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/zhu_xinyi/220711/' ## sub 13
# file = '/home/lcy/MEG_attention/lcy_MEG_0328/pan_ningxin/220711/' ## sub 14
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/zhang_zhengnan/220711/' ## sub 15
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/ni_can/220711/' ## sub 16
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/tang_yushun/220711/' ## sub 17
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/yin_zhiyuan/220712/' ## sub 18
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/deji_yangla/220712/' ## sub 19
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/liang_shuyu/220712/' ## sub 20
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/liu_chewei/220712/' ## sub 21
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/wang_siqi/220712/' ## sub 22
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/sun_yingning/220712/' ## sub 23 
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/guo_yang/220718/' ## sub 24
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/zuoteng_jizi/220718/' ## sub 25
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/chen_wangnan/220718/' ## sub 26
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/cheng_jianxin/220718/' ## sub 27
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/meng_ruishuang/220718/' ## sub 28
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/zhang_yidan/220719/' ## sub 29
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/xu_fangliang/220719/' ## sub 30
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/qiao_shan/220719/' ## sub 31
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/wang_mo/220719/' ## sub 32
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/yang_jing/220719/' ## sub 33
#file = '/home/lcy/MEG_attention/lcy_MEG_0328/huang_zheng/220328/' ## sub 01
file = '/home/lcy/MEG_attention/lcy_MEG_0328/bi_keyan/220328/' ## sub 02
raw_file = os.path.join(file,'run1_tsss.fif')
raw = mne.io.read_raw_fif(raw_file, preload = True)
# raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1233','MEG1212','MEG1412'] ## sub 02按照原有的标签来显示，
#raw.info['bads'] = ['MEG2023','MEG2042','MEG1812'] ## sub03
#raw.info['bads'] = ['MEG1512','MEG2023','MEG2043','MEG1812','MEG2633'] ## sub04
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub05
#raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub06
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812'] ## sub07
# raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG2031','MEG1512'] ## sub08
# raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512'] ## sub09
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub10
# raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub11
# raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub12
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub13
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub14
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub14
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub16
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub17
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub18
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2031'] ## sub19
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2333'] ## sub20
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub21
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub22
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub23
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub24
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub25
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub26
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123','MEG2531'] ## sub27
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub28
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub29
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG1933','MEG2142'] ## sub30
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub31
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub32
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub33
#raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1412','MEG1223','MEG1413','MEG1212'] ## sub01
raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1412','MEG1512'] ## sub02
raw = raw.copy().filter(l_freq = 0.04, h_freq = 45.0) ## filter
## ica for data
ica = mne.preprocessing.ICA(n_components=20,random_state=97,max_iter=800)
ica.fit(raw)
raw.load_data()
ica.plot_sources(raw, show_scrollbars=False) 
## main record ICA compontent
# ica.exclude  = [0,1] ## sub 01
#lica.exclude  = [0] ## sub02
#ica.exclude  = [6,8] ## sub03
# ica.exclude  = [0,2] ## sub04
# ica.exclude  = [0,1] ## sub05
# ica.exclude  = [0,12,15] ## sub06
#ica.exclude  = [0,1,14] ## sub07
#ica.exclude  = [0,1,6,18,19] ## sub08
#ica.exclude  = [1,2] ## sub09
#ica.exclude  = [0,2] ## sub10
#ica.exclude  = [0,1] ## sub11
#ica.exclude  = [0,1] ## sub12
#ica.exclude  = [0,11] ## sub13
#ica.exclude  = [0] ## sub14
#ica.exclude  = [0,3] ## sub15
#ica.exclude  = [0,3,17] ## sub16
#ica.exclude  = [0,1,17] ## sub17
#ica.exclude  = [0,1,18] ## sub18
#ica.exclude  = [0,16,17] ## sub19
#ica.exclude  = [0,1] ## sub20
#ica.exclude  = [0,15] ## sub21
#ica.exclude  = [0,15] ## sub22
#ica.exclude  = [0,8] ## sub23
#ica.exclude  = [0,6,1] ## sub24
#ica.exclude  = [0,19,1] ## sub25
#ica.exclude  = [0,6,1] ## sub26
#ica.exclude  = [0,1,7] ## sub27
#ica.exclude  = [0,1,3] ## sub28
#ica.exclude  = [0,4] ## sub29
#ica.exclude  = [0,1,9] ## sub30
#ica.exclude  = [0] ## sub31
#ica.exclude  = [0,3,5] ## sub32
#ica.exclude  = [0,5,6] ## sub33
#ica.exclude  = [0] ## sub01
ica.exclude  = [0] ## sub02
ica.plot_properties(raw, picks = ica.exclude)
# orig_raw = raw.copy()
raw.load_data()
ica.apply(raw)
## find events
tmin, tmax = -0.2000, 2.000
raw.copy().pick_types(meg = False, stim = True).plot(start = 46, duration = 1.998)
events = mne.find_events(raw, stim_channel= 'STI101', output = 'onset' , consecutive = True, min_duration = 0.01)
print ('Number of events:', len(events))
event_dict2 = {'attention1': 1,'attention2': 2,'attention3': 4,'attention4': 8}
epochs1 = mne.Epochs(raw, events, tmin=-0.2, tmax=2.0, event_id=event_dict2, preload = True)
epochs1.pick_types(meg=True, exclude='bads')
evoked=epochs1['attention1','attention2','attention3','attention4']
attention1_1 = epochs1['attention1'].average()
attention2_1 = epochs1['attention2'].average()
attention3_1 = epochs1['attention3'].average()
attention4_1 = epochs1['attention4'].average() 
del raw
raw_file = os.path.join(file,'run2_tsss.fif')
raw = mne.io.read_raw_fif(raw_file, preload = True)
# raw.info['bads'] = ['MEG2023','MEG2042','MEG1812'] ## sub03
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2043','MEG1812','MEG2633'] ## sub04
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub05
#raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub06
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812'] ## sub07
# raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG2031','MEG1512'] ## sub08
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512'] ## sub09
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub10
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub11
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub12
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub13
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub14
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub15
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub16
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub17
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub18
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2031'] ## sub19
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2333'] ## sub20
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub21
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub22
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub23
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub24
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub25
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub26
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123','MEG2531'] ## sub27
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub28
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub29
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG1933','MEG2142'] ## sub30
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub31
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub32
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub33
#raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1412','MEG1223','MEG1413','MEG1212'] ## sub01
raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1412','MEG1512'] ## sub02

# raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1233','MEG1212','MEG1412'] ## 按照原有的标签来显示，

raw = raw.copy().filter(l_freq = 0.04, h_freq = 45.0) ## filter
## ica for data
ica = mne.preprocessing.ICA(n_components=20,random_state=97,max_iter=800)
ica.fit(raw)
raw.load_data()
ica.plot_sources(raw, show_scrollbars=False) 
## run2 ica con
## ica.exclude  = [0,1,13] ## sub01
#ica.exclude  = [0,1,12] ## sub03
# ica.exclude  = [0] ## sub04
# ica.exclude  = [0] ## sub05
#ica.exclude  = [0] ## sub06
# ica.exclude  = [0] ## sub07
# ica.exclude  = [0,1] ## sub08
#ica.exclude  = [2,5] ## sub09
# ica.exclude  = [2,9] ## sub10
#ica.exclude  = [0,1] ## sub11
#ica.exclude  = [0,1] ## sub12
#ica.exclude  = [0,2] ## sub13
#ica.exclude  = [0,1] ## sub14
#ica.exclude  = [0,7] ## sub15
#ica.exclude  = [0,1,14] ## sub16
#ica.exclude  = [0,1,19] ## sub17
#ica.exclude  = [0,1,2] ## sub18
#ica.exclude  = [0,1,17] ## sub19
#ica.exclude  = [0,5] ## sub20
#ica.exclude  = [0] ## sub21
#ica.exclude  = [0,1,15] ## sub22
#ica.exclude  = [2,1] ## sub23
#ica.exclude  = [0] ## sub24
#ica.exclude  = [0,1] ## sub25
#ica.exclude  = [0,10,1] ## sub26
#ica.exclude  = [0,1,10] ## sub27
#ica.exclude  = [0,1] ## sub28
#ica.exclude  = [0] ## sub29
#ica.exclude  = [0,1,2] ## sub30
#ica.exclude  = [0] ## sub31
#ica.exclude  = [0,1,11] ## sub32
#ica.exclude  = [0,1,2,6] ## sub33
#ica.exclude  = [0,1] ## sub01
ica.exclude  = [0,1] ## sub02
ica.plot_properties(raw, picks = ica.exclude)
# orig_raw = raw.copy()
raw.load_data()
ica.apply(raw)
## find events
tmin, tmax = -0.2000, 2.000
raw.copy().pick_types(meg = False, stim = True).plot(start = 46, duration = 1.998)
events = mne.find_events(raw, stim_channel= 'STI101', output = 'onset' , consecutive = True, min_duration = 0.01)
print ('Number of events:', len(events))
event_dict2 = {'attention1': 1,'attention2': 2,'attention3': 4,'attention4': 8}
epochs2 = mne.Epochs(raw, events, tmin=-0.2, tmax=2.0, event_id=event_dict2, preload = True)
epochs2.pick_types(meg=True, exclude='bads')
evoked=epochs2['attention1','attention2','attention3','attention4']
attention1_2 = epochs2['attention1'].average() 
attention2_2 = epochs2['attention2'].average()        
attention3_2 = epochs2['attention3'].average()
attention4_2 = epochs2['attention4'].average()
del raw
raw_file = os.path.join(file,'run3_tsss.fif')
raw = mne.io.read_raw_fif(raw_file, preload = True)
#raw.info['bads'] = ['MEG2023','MEG2042','MEG1812'] ## sub03
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2043','MEG1812','MEG2633'] ## sub04
#raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub05
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub06
# raw.info['bads'] = ['MEG2042','MEG2023','MEG1812'] ## sub07
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG2031','MEG1512'] ## sub08
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512'] ## sub09
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub10
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub11
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub12
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub13
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub14
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub15
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub16
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub17
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub18
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2031'] ## sub19
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2333'] ## sub20
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub21
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub22
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub23
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub24
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub25
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub26
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123','MEG2531'] ## sub27
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub28
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub29
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG1933','MEG2142'] ## sub30
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub31
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub32
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub33
#raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1412','MEG1223','MEG1413','MEG1212'] ## sub01
raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1412','MEG1512'] ## sub02
#raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1233','MEG1212','MEG1412'] ## 按照原有的标签来显示，
raw = raw.copy().filter(l_freq = 0.04, h_freq = 45.0) ## filter
## ica for data
ica = mne.preprocessing.ICA(n_components=20,random_state=97,max_iter=800)
ica.fit(raw)
raw.load_data()
ica.plot_sources(raw, show_scrollbars=False) 
## run 3 component
#ica.exclude  = [0,16] ## sub03
# ica.exclude  = [0,6] ## sub04
# ica.exclude  = [0,1] ## sub05
#ica.exclude  = [1,3,12] ## sub06
#ica.exclude  = [0,1] ## sub07
#ica.exclude  = [0] ## sub08
# ica.exclude  = [0,3] ## sub09
# ica.exclude  = [0,7] ## sub10
#ica.exclude  = [0,1] ## sub11
#ica.exclude  = [0,1,16] ## sub12
#ica.exclude  = [0,13] ## sub13
#ica.exclude  = [0,1] ## sub14
#ica.exclude  = [0,1] ## sub15
#ica.exclude  = [0,1,17] ## sub16
#ica.exclude  = [0,19] ## sub17
#ica.exclude  = [0,1,3] ## sub18
#ica.exclude  = [1,18] ## sub19
#ica.exclude  = [0,1] ## sub20
#ica.exclude  = [0,10] ## sub21
#ica.exclude  = [0,17] ## sub22
#ica.exclude  = [2,1] ## sub23
#ica.exclude  = [0] ## sub24
#ica.exclude  = [1] ## sub25
#ica.exclude  = [0,3,11] ## sub26
#ica.exclude  = [0,1,12] ## sub27
#ica.exclude  = [0,2,13] ## sub28
#ica.exclude  = [0,1] ## sub29
#ica.exclude  = [0,1,12] ## sub30
#ica.exclude  = [0,1] ## sub31
#ica.exclude  = [4,10] ## sub32
#ica.exclude  = [0,1,5] ## sub33
#ica.exclude  = [0,6] ## sub01
ica.exclude  = [0,1] ## sub02
#############
ica.plot_properties(raw, picks = ica.exclude)
raw.load_data()
ica.apply(raw)
tmin, tmax = -0.2000, 2.000
raw.copy().pick_types(meg = False, stim = True).plot(start = 46, duration = 1.998)
events = mne.find_events(raw, stim_channel= 'STI101', output = 'onset' , consecutive = True, min_duration = 0.01)
print ('Number of events:', len(events))
event_dict2 = {'attention1': 1,'attention2': 2,'attention3': 4,'attention4': 8}
epochs3 = mne.Epochs(raw, events, tmin=-0.2, tmax=2.0, event_id=event_dict2, preload = True)
epochs3.pick_types(meg=True, exclude='bads')
evoked=epochs3['attention1','attention2','attention3','attention4']
attention1_3 = epochs3['attention1'].average()
attention2_3 = epochs3['attention2'].average()
attention3_3 = epochs3['attention3'].average()
attention4_3 = epochs3['attention4'].average()
## run 4
del raw
raw_file = os.path.join(file,'run4_tsss.fif')
raw = mne.io.read_raw_fif(raw_file, preload = True)

#raw.info['bads'] = ['MEG2023','MEG2042','MEG1812'] ## sub03
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2043','MEG1812','MEG2633'] ## sub04
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub05
#raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub06
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812'] ## sub07
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG2031','MEG1512'] ## sub08
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512'] ## sub09
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub10
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub11
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub12
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub13
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub14
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub15
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub16
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub17
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub18
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2031'] ## sub19
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2333'] ## sub20
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub21
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub22
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub23
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub24
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub25
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub26
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123','MEG2531'] ## sub27
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub28
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub29
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG1933','MEG2142'] ## sub30
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub31
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub32
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub33
#raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1412','MEG1223','MEG1413','MEG1212'] ## sub01
raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1412','MEG1512'] ## sub02
# raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1233','MEG1212','MEG1412'] ## 按照原有的标签来显示，
raw = raw.copy().filter(l_freq = 0.04, h_freq = 45.0) ## filter
## ica for data
ica = mne.preprocessing.ICA(n_components=20,random_state=97,max_iter=800)
ica.fit(raw)
raw.load_data()
ica.plot_sources(raw, show_scrollbars=False) 
## run 4 ica component
## ica.exclude  = [0,1] ## sub01
#ica.exclude  = [0,11] ## sub03
# ica.exclude  = [0] ## sub04
# ica.exclude  = [0,2] ## sub05
# ica.exclude  = [0] ## sub06
#ica.exclude  = [0] ## sub07
#ica.exclude  = [0,1] ## sub08
#ica.exclude  = [4,5] ## sub09
#ica.exclude  = [1,2] ## sub10
#ica.exclude  = [0,4] ## sub11
#ica.exclude  = [0,1] ## sub12
#ica.exclude  = [0,10] ## sub13
#ica.exclude  = [0,1] ## sub14
#ica.exclude  = [0,6] ## sub15
#ica.exclude  = [2,18] ## sub16
#ica.exclude  = [0,18] ## sub17
#ica.exclude  = [0,2] ## sub18
#ica.exclude  = [0,2,17] ## sub19
#ica.exclude  = [0,1] ## sub20
#ica.exclude  = [10,1] ## sub21
#ica.exclude  = [0,1,17] ## sub22
#ica.exclude  = [0,1] ## sub23
#ica.exclude  = [0,1] ## sub24
#ica.exclude  = [0,13,1] ## sub25
#ica.exclude  = [0,7] ## sub26
#ica.exclude  = [0,5,13] ## sub27
#ica.exclude  = [0,1,2] ## sub28
#ica.exclude  = [0,1] ## sub29
#ica.exclude  = [0,1] ## sub30
#ica.exclude  = [0] ## sub31
#ica.exclude  = [0,3,15] ## sub32
#ica.exclude  = [1,10] ## sub33
#ica.exclude  = [0,1] ## sub01
ica.exclude  = [0,1] ## sub02
## 
ica.plot_properties(raw, picks = ica.exclude)
raw.load_data()
ica.apply(raw)
tmin, tmax = -0.2000, 2.000
raw.copy().pick_types(meg = False, stim = True).plot(start = 46, duration = 1.998)
events = mne.find_events(raw, stim_channel= 'STI101', output = 'onset' , consecutive = True, min_duration = 0.01)
print ('Number of events:', len(events))
event_dict2 = {'attention1': 1,'attention2': 2,'attention3': 4,'attention4': 8}
epochs4 = mne.Epochs(raw, events, tmin=-0.2, tmax=2.0, event_id=event_dict2, preload = True)
epochs4.pick_types(meg=True, exclude='bads')
evoked=epochs4['attention1','attention2','attention3','attention4']
attention1_4 = epochs4['attention1'].average()
attention2_4 = epochs4['attention2'].average()
attention3_4 = epochs4['attention3'].average()
attention4_4 = epochs4['attention4'].average()
## 
#peaks1 =[]
#attention1 = attention1_1
data1 = attention1_1.get_data() + attention1_2.get_data() + attention1_3.get_data()+attention1_4.get_data()
data1 = data1/4
# attention1.data = data1/4
# attention1.plot(picks='mag', spatial_colors=True, gfp=True)
# attention1.plot_joint()
# peaks = attention1.get_peak(ch_type ='mag')
# peaks1.append(peaks)
# ##
# attention2 = attention2_1
data2 = attention2_1.get_data() + attention2_2.get_data() + attention2_3.get_data()+attention2_4.get_data()
data2 = data2/4
# attention2.data = data2/4
# attention2.plot(picks='mag', spatial_colors=True, gfp=True)
# attention2.plot_joint()
# peaks = attention2.get_peak(ch_type ='mag')
# peaks1.append(peaks)
##
#attention3 = attention3_1
data3 = attention3_1.get_data() + attention3_2.get_data() + attention3_3.get_data()+attention3_4.get_data()
data3 = data3/4
# attention3.data = data3/4
# attention3.plot(picks='mag', spatial_colors=True, gfp=True)
# attention3.plot_joint()
# peaks = attention3.get_peak(ch_type ='mag')
# peaks1.append(peaks)
##
#attention4 = attention4_1
data4 = attention4_1.get_data() + attention4_2.get_data() + attention4_3.get_data()+attention4_4.get_data()
data4 = data4/4
# attention4.data = data4/4
# attention4.plot(picks='mag', spatial_colors=True, gfp=True)
# attention4.plot_joint()
# peaks = attention4.get_peak(ch_type ='mag')
# peaks1.append(peaks)
## save peaks values
# np.save('/home/lcy/MEG_attention/preprocess/sub01peak.npy',peaks1)
##
## run 5 and run 6 
del raw 
raw_file = os.path.join(file,'run5_tsss.fif')
raw = mne.io.read_raw_fif(raw_file, preload = True)
#raw.info['bads'] = ['MEG2023','MEG2042','MEG1812'] ## sub03
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2043','MEG1812','MEG2633'] ## sub04
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub05
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub06
# raw.info['bads'] = ['MEG2042','MEG2023','MEG1812'] ## sub07
# raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG2031','MEG1512'] ## sub08
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512'] ## sub09
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub10
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub11
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub12
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub13
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub14
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub15
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub16
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub17
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub18
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2031'] ## sub19
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2333'] ## sub20
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub21
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub22
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub23
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub24
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub25
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub26
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123','MEG2531'] ## sub27
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub28
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub29
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG1933','MEG2142'] ## sub30
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub31
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub32
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub33
#raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1412','MEG1223','MEG1413','MEG1212'] ## sub01
raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1412','MEG1512'] ## sub02
#raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1412','MEG1223','MEG1413','MEG1212'] ## 按照原有的标签来显示，
raw = raw.copy().filter(l_freq = 0.04, h_freq = 45.0) ## filter
## ica for data
ica = mne.preprocessing.ICA(n_components=20,random_state=97,max_iter=800)
ica.fit(raw)
raw.load_data()
ica.plot_sources(raw, show_scrollbars=False) 
#ica.exclude  = [0,5] ## number in pyrhon from 0 sub03
# ica.exclude  = [0] ## sub04
# ica.exclude  = [0,1] ## sub05
#ica.exclude  = [0,11,18] ## sub06
#ica.exclude  = [0,1] ## sub07
# ica.exclude  = [0,1,5,16] ## sub08
#ica.exclude  = [0,3,4] ## sub09
#ica.exclude  = [0,1] ## sub10
#ica.exclude  = [0,1,13] ## sub11
#ica.exclude  = [0,1] ## sub12
#ica.exclude  = [0,1,2] ## sub13
#ica.exclude  = [0,1] ## sub14
#ica.exclude  = [0,1,8] ## sub15
#ica.exclude  = [0,1,17] ## sub16
#ica.exclude  = [0,2,16] ## sub17
#ica.exclude  = [0,1,2] ## sub18
#ica.exclude  = [0,1,17] ## sub19
#ica.exclude  = [0,1] ## sub20
#ica.exclude  = [0,1] ## sub21
#ica.exclude  = [0,1,18] ## sub22
#ica.exclude  = [0,1] ## sub23
#ica.exclude  = [0,2] ## sub24
#ica.exclude  = [0,13,1] ## sub25
#ica.exclude  = [0,1,10] ## sub26
#ica.exclude  = [0,3,9] ## sub27
#ica.exclude  = [0,1,2,3] ## sub28
#ica.exclude  = [0,1] ## sub29
#ica.exclude  = [0,1,15] ## sub30
#ica.exclude  = [0,1] ## sub31
#ica.exclude  = [0,1,11] ## sub32
#ica.exclude  = [0,1,4] ## sub33
#ica.exclude  = [0,1] ## sub01
ica.exclude  = [0,11] ## sub02
ica.plot_properties(raw, picks = ica.exclude)
# orig_raw = raw.copy()
raw.load_data()
ica.apply(raw)
## find events
tmin, tmax = -0.1000, 6.033
raw.copy().pick_types(meg = False, stim = True).plot(start = 46, duration = 1.998)
events = mne.find_events(raw, stim_channel= 'STI101', output = 'onset' , consecutive = True, min_duration = 0.01)
print ('Number of events:', len(events))
event_dict = {'Left_att': 1,'Right_att': 2}
epochs = mne.Epochs(raw, events, tmin=-0.1, tmax=6.033, event_id=event_dict, preload = True)
epochs.pick_types(meg=True, exclude='bads')
evoked=epochs['Left_att','Right_att']
left_evoked1 = epochs['Left_att'].average()
right_evoked1 = epochs['Right_att'].average()
###########################
#np.save('/home/lcy/MEG_attention/preprocess/sub01_run5_1.npy',run5_1)
## run 6 
del raw
del epochs
raw_file = os.path.join(file,'run6_tsss.fif')
raw = mne.io.read_raw_fif(raw_file, preload = True)
#raw.info['bads'] = ['MEG2023','MEG2042','MEG1812'] ## sub03
## raw.info['bads'] = ['MEG1512','MEG2023','MEG2043','MEG1812','MEG2633'] ## sub04
# raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub05
#raw.info['bads'] = ['MEG1512','MEG2023','MEG2042','MEG1812','MEG2633'] ## sub06
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812'] ## sub07
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG2031','MEG1512'] ## sub08
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512'] ## sub09
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub10
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub11
#raw.info['bads'] = ['MEG2042','MEG2633','MEG1812','MEG1512','MEG2031'] ## sub12
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub13
# raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub14
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub15
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub16
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub17
#raw.info['bads'] = ['MEG2042','MEG2023','MEG1812','MEG1512','MEG2031'] ## sub18
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2031'] ## sub19
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512','MEG2333'] ## sub20
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub21
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub22
#raw.info['bads'] = ['MEG2042','MEG1812','MEG1512'] ## sub23
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub24
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub25
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub26
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123','MEG2531'] ## sub27
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub28
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512'] ## sub29
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG1933','MEG2142'] ## sub30
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub31
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub32
#raw.info['bads'] = ['MEG2042','MEG2031','MEG1812','MEG1512','MEG2123'] ## sub33
#raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1412','MEG1223','MEG1413','MEG1212'] ## sub01
raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1412','MEG1512'] ## sub02

# raw.info['bads'] = ['MEG2031','MEG2042','MEG1812','MEG1422','MEG1423','MEG1512','MEG1412','MEG1223','MEG1413','MEG1212'] ## 按照原有的标签来显示，
raw = raw.copy().filter(l_freq = 0.04, h_freq = 45.0) ## filter
## ica for data
ica = mne.preprocessing.ICA(n_components=20,random_state=97,max_iter=800)
ica.fit(raw)
raw.load_data()
ica.plot_sources(raw, show_scrollbars=False) 
#ica.exclude  = [0,9] ## number in pyrhon from 0 sub03
# ica.exclude  = [0,1] ## sub04
#ica.exclude  = [0,3] ## sub05
#ica.exclude  = [0,15] ## sub06
# ica.exclude  = [0,1] ## sub07
# ica.exclude  = [0,3] ## sub08
# ica.exclude  = [0,2,4] ## sub09
#ica.exclude  = [0,1] ## sub10
#ica.exclude  = [1,18] ## sub11
#ica.exclude  = [0,1,3] ## sub12
#ica.exclude  = [0,1,3] ## sub13
#ica.exclude  = [0,1] ## sub14
#ica.exclude  = [0,1,3] ## sub15
#ica.exclude  = [0,1,19] ## sub16
#ica.exclude  = [0,3] ## sub17
#ica.exclude  = [0,2] ## sub18
#ica.exclude  = [0,1,16] ## sub19
#ica.exclude  = [0,1] ## sub20
#ica.exclude  = [0,1,5] ## sub21
#ica.exclude  = [0,1,18] ## sub22
#ica.exclude  = [0,1] ## sub23
#ica.exclude  = [2,3] ## sub24
#ica.exclude  = [0,1] ## sub25
#ica.exclude  = [0,1,10] ## sub26
#ica.exclude  = [0,1,10] ## sub27
#ica.exclude  = [0,1,3] ## sub28
#ica.exclude  = [0,1] ## sub29
#ica.exclude  = [0,1,7] ## sub30
#ica.exclude  = [0,1] ## sub31
#ica.exclude  = [0,1,15] ## sub32
#ica.exclude  = [0,1,12] ## sub33
#ica.exclude  = [0,2] ## sub01
ica.exclude  = [0] ## sub02
ica.plot_properties(raw, picks = ica.exclude)
# orig_raw = raw.copy()
raw.load_data()
ica.apply(raw)
## find events
tmin, tmax = -0.1000, 6.033
raw.copy().pick_types(meg = False, stim = True).plot(start = 46, duration = 1.998)
events = mne.find_events(raw, stim_channel= 'STI101', output = 'onset' , consecutive = True, min_duration = 0.01)
print ('Number of events:', len(events))
event_dict = {'Left_att': 1,'Right_att': 2}
epochs = mne.Epochs(raw, events, tmin=-0.1, tmax=6.033, event_id=event_dict, preload = True)
epochs.pick_types(meg=True, exclude='bads')
evoked=epochs['Left_att','Right_att']
#######################################################
left_evoked2 = epochs['Left_att'].average()
right_evoked2 = epochs['Right_att'].average()
############
data5 = left_evoked1.get_data() + left_evoked2.get_data()
data6 = right_evoked1.get_data() + right_evoked2.get_data()
##
data5 = data5/2
data6 = data6/2
# run6_1 = evoked.get_data()
np.save('/media/lcy/lcy2/preprocess/sub02data1.npy',data1)
np.save('/media/lcy/lcy2/preprocess/sub02data2.npy',data2)
np.save('/media/lcy/lcy2/preprocess/sub02data3.npy',data3)
np.save('/media/lcy/lcy2/preprocess/sub02data4.npy',data4)
np.save('/media/lcy/lcy2/preprocess/sub02data5.npy',data5)
np.save('/media/lcy/lcy2/preprocess/sub02data6.npy',data6)
## 












































