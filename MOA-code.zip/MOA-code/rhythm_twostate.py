#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 15 08:20:30 2023

@author: lcy
"""
## The rhythm for two state
##
import yaml
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
import scipy
import pandas as pd
from scipy import signal
import os
import numpy as np
import mne
from copy import deepcopy
import matplotlib.pyplot as plt
from matplotlib import font_manager
import matplotlib.mlab as mlab
from scipy.io import savemat
## 
def window(x, win):
    """ Apply a window to a segment of data

    Parameters
    ----------
    x : np.ndarray
        The data
    win : np.ndarray
        The window
    Returns
    -------
    x : np.ndarray
        The windowed data
    """
    return np.multiply(win, x.T).T
    #return np.multiply(win, x.T).T
## what the meaning of this window?
def window(x1, win):
    """ Apply a window to a segment of data

    Parameters
    ----------
    x : np.ndarray
        The data
    win : np.ndarray
        The window
    Returns
    -------
    x : np.ndarray
        The windowed data
    """
    return np.multiply(win, x1.T).T
## define smoth (Triangular Moving Averger)
def smoothTriangle(data, degree):  
   triangle = np.concatenate((np.arange(degree +1), np.arange(degree)[::-1]))
   smoothed = []
   for i in range(degree, len(data)-degree*2):
       point = data[i:i+len(triangle)]*triangle
       smoothed.append(np.sum(point)/np.sum(triangle))
## Handle boundaries
   smoothed = [smoothed[0]]*int(degree + degree/2) + smoothed
   while len(smoothed) < len(data):
       smoothed.append(smoothed[-1])
   return smoothed
## define time_shuffled_perm (analysis_fnc, x, k_perm) %% 列出至少两种的统计方式的分析！
def time_shuffled_perm(analysis_fnc, x, k_perm):
    """
    Run a permutation test by shuffling the time-stamps of individual trials.

    Parameters
    ----------
    analysis_fnc : function
        The function that will be used to generate the spectrum
    x : np.ndarray
        The data time-series
    k_perm : int
        How many permutations to run

    Returns
    -------
    res : dict
        Dictionary of the results of the randomization analysis
        x : np.ndarray
            The raw data
        x_perm : np.ndarray
            The shuffled data
        f : np.ndarray
            The frequencies of the resulting spectrum
        y_emp : np.ndarray
            The spectrum of the empirical (unshuffled) data
        y_avg : np.ndarray
            The spectra of the shuffled permutations
        y_cis : np.ndarray
            Confidence intervals for the spectra, at the 2.5th, 95th, and
            97.5th percentile
        p : np.ndarray
            P-values (uncorrected for multiple comparisons) for each frequency
    """
    # Compute the empirical statistics
    f, y_emp = analysis_fnc(x)
    # Run a bootstrapped permutation test.
    # Create a surrogate distribution by randomly shuffling resps in time.
    x_perm = []
    y_perm = []
    x_shuff = x.copy()
    for k in range(k_perm):
        np.random.shuffle(x_shuff)
        _, y_perm_k = analysis_fnc(x_shuff)
        y_perm.append(y_perm_k)
        if k < 10:  # Keep a few permutations for illustration
            x_perm.append(x_shuff.copy())
    # Find statistically significant oscillations
    # Sometimes we get p=0 if no perms are larger than emp. Note that in this
    # case, a Bonferroni correction doesn't have any effect on the p-values.
    p = np.mean(np.vstack([y_perm, y_emp]) > y_emp, axis=0)
    # Get summary of simulated spectra
    y_avg = np.mean(y_perm, 1)
    y_cis = np.percentile(y_perm, [2.5, 95, 97.5], 1)
    # Bundle the results together
    res = {}
    res['x'] = x
    res['x_perm'] = np.array(x_perm)
    res['f'] = f
    res['y_emp'] = y_emp
    res['y_perm'] = np.array(y_perm)
    res['y_avg'] = y_avg
    res['y_cis'] = y_cis
    res['p'] = p
    return res 

## class for paixu
sta1_len =[]
sta2_len = []
y1 = []
f1 = []
p1 = []
for i in range(33):
    fileName1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/corr/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_left_corr1_1s.npy'
    state1 = np.load(fileName1)
    fileName2 = '/media/lcy/lcy2/preprocess/New Folder/temporal/corr/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_left_corr2_1s.npy'
    #fileName2 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' +'sub'+ str('%02d' %(i+1)) +'slid_righttemporal_MI4.npy'
    #fileName2 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' + 'sub'+ str('%02d' %(i+1)) +'temporalleft_MI4.npy'
    state2 = np.load(fileName2)
    sta_index1 = []
    sta_index2 = []
    m = len(state1[1])
    # sta1_len =[]
    # sta2_len = []
    for i in range(m):
        state1_trail = state1[:,i]
        state2_trail = state2[:,i]
        # sta_index1 = []
        # sta_index2 = []
        for l in range(4000):
            sta1 = state1_trail[l]
            sta2 = state2_trail[l]
            sta_ind1 = []
            sta_ind2 = []
            if sta1 > sta2:
                sta_ind1 = 1
                sta_ind2 = 0
            if sta2 > sta1:
                sta_ind1 = 0
                sta_ind2 = 1
            sta_index1.append(sta_ind1)
            sta_index2.append(sta_ind2)
    x = sta_index1
        ## shuffle and data
    ## Detrend the data 
    detrend_ord = 1
    x = sm.tsa.tsatools.detrend(x, order = detrend_ord)
    ## Window the data
    x = window(x,np.hanning(len(x)))
    ## smoth data %% Triangular Moving Averger 
    x = smoothTriangle(x, 40) ## setting degree to 10
    ##
    fs = 2000  ## Sampling rate
    nfft = 2000 ## the number of samples in the DFT
    axis = -1 ##  int, the axis of the array along which to calculate the DFT 
    y = np.abs(np.fft.fft(x,nfft,axis = axis)[:40]) ## the amplitude specture
    f = np.fft.fftfreq(nfft, 1/fs)[: 40]
    f_keep = f>0
    y1.append(y)
    f1.append(f)
    ### shuffle time for identify p
    x_perm = []
    y_perm = []
    x_shuff = x.copy()
    for k in range(5000):
        np.random.shuffle(x_shuff)
        y_perm_k = np.abs(np.fft.fft(x_shuff,nfft,axis = axis)[:40])
        #_, y_perm_k = analysis_fnc(x_shuff)
        y_perm.append(y_perm_k)
        if k < 10:  # Keep a few permutations for illustration
            x_perm.append(x_shuff.copy())
    # Find statistically significant oscillations
    # Sometimes we get p=0 if no perms are larger than emp. Note that in this
    # case, a Bonferroni correction doesn't have any effect on the p-values.
    p = np.mean(np.vstack([y_perm, y]) > y, axis=0) ## 可以在尝试一种统计方式用得到P值分析
    p1.append(p)   
        
        
        
        
        
new_sta2 = list(filter(lambda x:2000>x>28,sta2_len)) ## 选择的余地是依据大致HZ，剔除一些小的持续情况的变化，可能是伪迹，剔除的是过大
new_sta1 = list(filter(lambda x:2000>x>28,sta1_len))
## sae 
# from numpy import *
# new_sta11 = mat(new_sta1)
# file1 = '/home/lcy/MEG_attention/state/corr1/duration/temporal_left_sta1.mat'
# scipy.io.savemat(file1, {'sta1': new_sta11})
# new_sta12 = mat(new_sta2)
# file2 = '/home/lcy/MEG_attention/state/corr1/duration/temporal_left_sta2.mat'
# scipy.io.savemat(file2, {'sta2': new_sta12})
## fi
from scipy import stats, integrate
import seaborn as sns
#sns.distplot(new_sta2, bins = 50, kde = False, fit = stats.gamma)
# sns.histplot(new_sta2, bins = 60, binrange = (1,2000), kde = True,stat = 'density') ## binrange is set to lowest and highest value for bin edges
#                                                                      ## Defaults to data extremes, kde (kernel density estimate)
# plt.show()
## no filter
mean_sta1_left = np.mean(sta1_len)
mean_sta2_left = np.mean(sta2_len )
## 绘制两个直方图到一张图中
font1 = {'family':'Times New Roman', 'weight':'normal','size': 14}
font2 = {'family':'Times New Roman',  'weight':'bold','size': 14}
fig,(ax1, ax2) = plt.subplots(1,2, figsize = (16,8))
fig.suptitle ('temporal (Left)', fontsize = 20)
axessub = sns.histplot(new_sta1, bins = 100, binrange = (1,2000), kde = True, stat = 'density', ax = ax1)
#ax1.hist(new_sta1, bins = 40,range = (1,2000),kde = True)
#ax1.sns.histplot(new_sta2, bins = 60, binrange = (1,2000), kde = True,stat = 'density')
axessub.set_title('State 1',font1)
axessub.set_xlabel('Duration (ms)',font1)
#ax1.set_ylabel('Frequency', font1)
axessub2 = sns.histplot(new_sta2, bins = 100, binrange = (1,2000), kde = True,stat = 'density', ax = ax2)
#ax2.hist(new_sta2, bins = 40,range = (1,2000))
axessub2.set_title('State 2',font1)
axessub2.set_xlabel('Duration (ms)',font1)
#plt.xlabel('Duration (ms)',font1)
plt.show()
plt.rcParams['savefig.dpi'] = 300 
name1 = '/home/lcy/MEG_attention/state/corr/temporal_left_sta1vs2.png'
plt.savefig(name1)
## state 3 vs state 4 
sta3_len =[]
sta4_len = []
for i in range(33):
    fileName1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/corr/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_left_corr4_1s.npy'
    #fileName1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' + 'sub'+ str('%02d' %(i+1)) +'temporalleft_MI1.npy'
    #fileName1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' +'sub'+ str('%02d' %(i+1)) +'slid_righttemporal_MI1.npy'
    state1 = np.load(fileName1)
    fileName2 = '/media/lcy/lcy2/preprocess/New Folder/temporal/corr/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_left_corr3_1s.npy'
    #fileName2 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' +'sub'+ str('%02d' %(i+1)) +'slid_righttemporal_MI4.npy'
    #fileName2 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' + 'sub'+ str('%02d' %(i+1)) +'temporalleft_MI4.npy'
    state2 = np.load(fileName2)
    sta_index1 = []
    sta_index2 = []
    m = len(state1[1])
    # sta1_len =[]
    # sta2_len = []
    for i in range(m):
        state1_trail = state1[:,i]
        state2_trail = state2[:,i]
        # sta_index1 = []
        # sta_index2 = []
        for l in range(4000):
            sta1 = state1_trail[l]
            sta2 = state2_trail[l]
            sta_ind1 = []
            sta_ind2 = []
            if sta1 > sta2:
                sta_ind1 = 1
                sta_ind2 = 0
            if sta2 > sta1:
                sta_ind1 = 0
                sta_ind2 = 1
            sta_index1.append(sta_ind1)
            sta_index2.append(sta_ind2)
        nums = sta_index1
        cut_continue = ob.solve(nums) ## 将连续的数字进行分段
        m1 = len(cut_continue)
        for q in range (m1):
            num = cut_continue[q]
            if num[0]==1:
                num1 = len(num)
                sta3_len.append(num1)
            if num[0] == 0:
                num2 = len(num)
                sta4_len.append(num2)
new_sta3 = list(filter(lambda x:2000>x>28,sta3_len)) ## 选择的余地是依据大致HZ，剔除一些小的持续情况的变化，可能是伪迹，剔除的是过大
new_sta4 = list(filter(lambda x:2000>x>28,sta4_len))
## filter 
# new_sta31 = mat(new_sta3)
# file3 = '/home/lcy/MEG_attention/state/corr1/duration/temporal_left_sta3.mat'
# scipy.io.savemat(file3, {'sta3': new_sta31})
# new_sta41 = mat(new_sta4)
# file4 = '/home/lcy/MEG_attention/state/corr1/duration/temporal_left_sta4.mat'
# scipy.io.savemat(file4, {'sta4': new_sta41})


# mean_sta3_left = np.mean(new_sta3)
# mean_sta4_left = np.mean(new_sta4)
## no filter
mean_sta3_left = np.mean(sta3_len)
mean_sta4_left = np.mean(sta4_len)
## 
font1 = {'family':'Times New Roman', 'weight':'normal','size': 14}
font2 = {'family':'Times New Roman',  'weight':'bold','size': 14}
fig,(ax1, ax2) = plt.subplots(1,2, figsize = (16,8))
fig.suptitle ('temporal (Left)', fontsize = 20)
axessub3 = sns.histplot(new_sta3, bins = 100, binrange = (1,2000), kde = True, stat = 'density', ax = ax1)
#n, bins, patches = ax1.hist(new_sta3, bins = 40,range = (1,2000), facecolor = 'blue', alpha = 0.5)  ## 返回直方图的值，并在此基础上进行拟合曲线
# y = mlab.gampdf(bins,100,5)
# plt.plot(bins,y,'r--')
axessub3.set_title('State 3',font1)
axessub3.set_xlabel('Duration (ms)',font1)
#ax1.set_ylabel('Frequency', font1)
axessub4 = sns.histplot(new_sta4, bins = 100, binrange = (1,2000), kde = True, stat = 'density', ax = ax2)
#axessub4.hist(new_sta4, bins = 40,range = (1,2000))
axessub4.set_title('State 4',font1)
axessub4.set_xlabel('Duration (ms)',font1)
plt.show()
plt.rcParams['savefig.dpi'] = 300 
name2 = '/home/lcy/MEG_attention/state/corr/temporal_left_sta3vs4.png'
plt.savefig(name2)
