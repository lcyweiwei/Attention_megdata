#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May  1 20:37:10 2022

@author: lcy
"""
###########3 decoder qingkuang 这里是以估计出的状态特征量来估计decoding 的情况
import os
import numpy as np
import mne
from copy import deepcopy
import matplotlib.pyplot as plt
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
## classifier
from  sklearn import svm
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
##  from sklearn to mne
from mne.decoding import (SlidingEstimator, GeneralizingEstimator, Scaler, cross_val_multiscore, LinearModel, 
                          get_coef, Vectorizer, CSP)
import scipy.io as sio
############
file3 = '/home/lcy/MEG_attention/preprocess/New Folder/corr/sub01att1.npy'
att1 = np.load(file3)
file4 = '/home/lcy/MEG_attention/preprocess/New Folder/corr/sub01att2.npy'
att2 = np.load(file4)
file5 = '/home/lcy/MEG_attention/preprocess/New Folder/corr/sub01att3.npy'
att3 = np.load(file5)
file6 = '/home/lcy/MEG_attention/preprocess/New Folder/corr/sub01att4.npy'
att4 = np.load(file6)
######### N 100 成分
state1_1 = att1[:,:,251:300]
state2_1 = att2[:,:,251:300]
state3_1 = att3[:,:,251:300]
state4_1 = att4[:,:,251:300]
sta1_1 = np.mean(state1_1, axis=2)
sta2_1 = np.mean(state2_1, axis=2)
sta3_1 = np.mean(state3_1, axis=2)
sta4_1 = np.mean(state4_1, axis=2)
#####
state1_1 = att1[:,:,251:300]
state2_1 = att2[:,:,251:300]
state3_1 = att3[:,:,251:300]
state4_1 = att4[:,:,251:300]
sta1_1 = np.mean(state1_1, axis=2)
sta2_1 = np.mean(state2_1, axis=2)
sta3_1 = np.mean(state3_1, axis=2)
sta4_1 = np.mean(state4_1, axis=2)

### N 170 成分
state1_2 = att1[:,:,331:380]
state2_2 = att2[:,:,331:380]
state3_2 = att3[:,:,331:380]
state4_2 = att4[:,:,331:380]
sta1_2 = np.mean(state1_2, axis=2)
sta2_2 = np.mean(state2_2, axis=2)
sta3_2 = np.mean(state3_2, axis=2)
sta4_2 = np.mean(state4_2, axis=2)
## N 300成分
state1_3 = att1[:,:,401:450]
state2_3 = att2[:,:,401:450]
state3_3 = att3[:,:,401:450]
state4_3 = att4[:,:,401:450]
##############
sta1_3 = np.mean(state1_3, axis=2)
sta2_3 = np.mean(state2_3, axis=2)
sta3_3 = np.mean(state3_3, axis=2)
sta4_3 = np.mean(state4_3, axis=2)
############# N 600 成分
state1_4 = att1[:,:,501:550]
state2_4 = att2[:,:,501:550]
state3_4 = att3[:,:,501:550]
state4_4 = att4[:,:,501:550]
##############
sta1_4 = np.mean(state1_4, axis=2)
sta2_4 = np.mean(state2_4, axis=2)
sta3_4 = np.mean(state3_4, axis=2)
sta4_4 = np.mean(state4_4, axis=2)
############# 
state1 = np.hstack((sta1_1,sta1_2,sta1_3,sta1_4))
state2 = np.hstack((sta2_1,sta2_2,sta2_3,sta2_4))
state3 = np.hstack((sta3_1,sta3_2,sta3_3,sta3_4))
state4 = np.hstack((sta4_1,sta4_2,sta4_3,sta4_4))
## N 500 成分

X = np.vstack((state1,state3))
a=np.ones(92)
b=np.zeros(92)
c=np.append(a,b)
y = c
#####################3 decode information 
accury_list_DN = []
epoch_num = 100
for i in range(epoch_num):
    clf=RandomForestClassifier(bootstrap=True, class_weight=None, criterion='gini',
                max_depth=None, max_features='sqrt', max_leaf_nodes=None,
                min_impurity_decrease=0.0, min_impurity_split=None,
                min_samples_leaf=1, min_samples_split=2,
                min_weight_fraction_leaf=0.0, n_estimators=40, n_jobs=1,
                oob_score=False, random_state=None, verbose=0, warm_start=False)
#clf = svm.SVC(kernel = 'linear', C=1, random_state = 40)
    scores = cross_val_score(clf, X, y, cv = 10)
    accury=np.mean(scores)
    accury_list_DN.append(accury) 

#scores = cross_val_multiscore(clf, X, y, cv=5, n_jobs=1)












