#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 13 14:15:03 2023

@author: lcy
"""
### cluster via unsupuer
from sklearn.cluster import KMeans
import numpy as np
from tslearn.clustering import TimeSeriesKMeans ## 
from tslearn.datasets import CachedDatasets
########################
## Corr 采用皮尔逊相关系来计算两个向量之间的线性相度
from scipy.stats import pearsonr
import matplotlib.pyplot as plt
from scipy.stats import ttest_ind
# Generate some sample data
#X_train,y_train, _, _ = CachedDatasets().load_dataset("Trace")
## X = np.random.rand(1000,2) ## 可以随意设置数据的维度
########################
def find_max_index(arr):
    max_index = 0
    for i in range (1,len(arr)):
        if arr[i] > arr[max_index]:
            max_index = i
    return max_index
#################  
color_rgb4 = (0/255,0/255,128/255)  ## state 4
color_rgb1 = (0/255,128/255,128/255) ## State 1
color_rgb2 = (0/255,0/255,255/255) ## State 2
color_rgb3 = (128/255,0/255,128/255) ## State 3
color_base = (192/255,192/255,192/255) ## baseline
## 导入我的数据分析
colors = [(0/255,0/255,128/255),(192/255,192/255,192/255),(0/255,128/255,128/255),(192/255,192/255,192/255),(0/255,0/255,255/255),(192/255,192/255,192/255),(128/255,0/255,128/255),(192/255,192/255,192/255)]
# cluster1_ind = []
# cluster2_ind = []
# cluster3_ind = []
# cluster4_ind = []
# ##
# cluster1_1_base_ind = []
# cluster2_1_base_ind = []
# cluster3_1_base_ind = []
# cluster4_1_base_ind = []
# ##
# cluster1_1_1_base_ind = []
# cluster2_1_1_base_ind = []
# cluster3_1_1_base_ind = []
# cluster4_1_1_base_ind = []

# ## All subject
# ## fileName1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftwhole_MI1_trial.npy'
# # for i in range(33):
# #     filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalright_att.npy'
# #     #filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeright_att.npy'
# #     data1 = np.load(filename)
# #     ###########
# #     #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeleft_att.npy'
# #     filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalleft_att.npy'  
# #     # filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalleft_att.npy'
# #     data2= np.load(filename2)
# #     data = np.vstack((data1, data2))
# #     ####
# #     # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate1.npy'
# #     # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate2.npy'
# #     # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate3.npy'
# #     # filename6 = '/media/lcy/lcy2/preprocess/New Folder/whole/state/sub31wholestate4.npy'
# #     filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalstate1.npy'
# #     filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalstate2.npy'
# #     filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalstate3.npy'
# #     filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalstate4.npy'      
# #     # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate1.npy'
# #     # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate2.npy'
# #     # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate3.npy'
# #     # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate4.npy'
# #     state1 = np.load(filename3)
# #     state1_1 = state1[:,:,201:301]
# #     state1_2 = np.mean(state1_1, axis = 0)
# #     state1_3 = np.mean(state1_2, axis = 1)
    
# #     state2 = np.load(filename4)
# #     state2_1 = state2[:,:,201:301]
# #     state2_2 = np.mean(state2_1, axis = 0)
# #     state2_3 = np.mean(state2_2, axis = 1)
# #     state3 = np.load(filename5)
# #     state3_1 = state3[:,:,201:301]
# #     state3_2 = np.mean(state3_1, axis = 0)
# #     state3_3 = np.mean(state3_2, axis = 1)
# #     state4 = np.load(filename6)
# #     state4_1 = state4[:,:,201:301]
# #     state4_2 = np.mean(state4_1, axis = 0)
# #     state4_3 = np.mean(state4_2, axis = 1)
# #     ##########################  baseline data imported 
    
# #     #state1 = np.load(filename3)
# #     state1_1_base = state1[:,:,100:200]
# #     state1_2_base = np.mean(state1_1_base, axis = 0)
# #     state1_3_base = np.mean(state1_2_base, axis = 1)
    
# #     #state2 = np.load(filename4)
# #     state2_1_base = state2[:,:,100:200]
# #     state2_2_base = np.mean(state2_1_base, axis = 0)
# #     state2_3_base = np.mean(state2_2_base, axis = 1)
# #     #state3 = np.load(filename5)
# #     state3_1_base = state3[:,:,100:200]
# #     state3_2_base = np.mean(state3_1_base, axis = 0)
# #     state3_3_base = np.mean(state3_2_base, axis = 1)
# #     #state4 = np.load(filename6)
# #     state4_1_base = state4[:,:,100:200]
# #     state4_2_base = np.mean(state4_1_base, axis = 0)
# #     state4_3_base = np.mean(state4_2_base, axis = 1)
# #     ##
# #     basedata = (state2_3_base + state1_3_base + state3_3_base + state4_3_base)/4
    
 
    
# #     #####################
# #     #############
# #     for i in range(100):
# #         cluster_data = data[i,:,154:1154].T
# #         X = cluster_data
# #         # km = TimeSeriesKMeans(n_clusters = 4,  metric = 'dtw', max_iter = 5, random_state=0) 
# #         ## 如果聚类的个数设置为2的情况下
# #         km = TimeSeriesKMeans(n_clusters = 2,  metric = 'dtw', max_iter = 5, random_state=0)
# #         km.fit(X)
# #         labels = km.labels_
# #         centroids = km.cluster_centers_
# #         print(labels)
# #         print(centroids)
# #         cluster_state1 = centroids[0,:,0]
# #         cluster_state2 = centroids[1,:,0]
# #         ####
# #         # cluster_state3 = centroids[2,:,0]
# #         # cluster_state4 = centroids[3,:,0]
# #         ##  original state1
        
# #         peaeson_corr1, _ = pearsonr(state1_3, cluster_state1)
# #         peaeson_corr1_base, _ = pearsonr(state1_3_base, cluster_state1)
# #         ###
# #         peaeson_corr2, _ = pearsonr(state2_3, cluster_state1)
# #         peaeson_corr2_base, _ = pearsonr(state2_3_base, cluster_state1)
# #         ##
# #         peaeson_corr3_base, _ = pearsonr(state3_3_base, cluster_state1)
# #         peaeson_corr3, _ = pearsonr(state3_3, cluster_state1)
# #        ##############333
# #         peaeson_corr4, _ = pearsonr(state4_3, cluster_state1)
# #         peaeson_corr4_base, _ = pearsonr(state4_3_base, cluster_state1)
# #         ########################
# #         peaeson_corr_base, _ = pearsonr(basedata, cluster_state1)
               
        
# #         ## 
# #         peaeson_corr1_1, _ = pearsonr(state1_3, cluster_state2)
# #         peaeson_corr2_1, _ = pearsonr(state2_3, cluster_state2)
# #         peaeson_corr3_1, _ = pearsonr(state3_3, cluster_state2)
# #         peaeson_corr4_1, _ = pearsonr(state4_3, cluster_state2)
# #         #####################
# #         peaeson_corr1_1_base, _ = pearsonr(state1_3_base, cluster_state2)
# #         peaeson_corr2_1_base, _ = pearsonr(state2_3_base, cluster_state2)
# #         peaeson_corr3_1_base, _ = pearsonr(state3_3_base, cluster_state2)
# #         peaeson_corr4_1_base, _ = pearsonr(state4_3_base, cluster_state2)
# #         ############
        
# #         #peaeson_corr_base_1, _ = pearsonr(basedata, cluster_state2)
# #         ##########
# #         # peaeson_corr1_2, _ = pearsonr(state1_3, cluster_state3)
# #         # peaeson_corr2_2, _ = pearsonr(state2_3, cluster_state3)
# #         # peaeson_corr3_2, _ = pearsonr(state3_3, cluster_state3)
# #         # peaeson_corr4_2, _ = pearsonr(state4_3, cluster_state3)
# #         # ###################
# #         # peaeson_corr1_3, _ = pearsonr(state1_3, cluster_state4)
# #         # peaeson_corr2_3, _ = pearsonr(state2_3, cluster_state4)
# #         # peaeson_corr3_3, _ = pearsonr(state3_3, cluster_state4)
# #         # peaeson_corr4_3, _ = pearsonr(state4_3, cluster_state4)
# #         ###  xuanze cluster1 according to  which state 
# #         ##
# #         cluster1_index = [peaeson_corr1, peaeson_corr2, peaeson_corr3, peaeson_corr4,peaeson_corr_base]
# #         cluster11_index = find_max_index(cluster1_index)
# #         cluster1_ind.append(cluster11_index)
# #         cluster2_index = [peaeson_corr1_1, peaeson_corr2_1, peaeson_corr3_1, peaeson_corr4_1,peaeson_corr_base_1]
# #         cluster22_index = find_max_index(cluster2_index)
# #         cluster2_ind.append(cluster22_index)
# #         # cluster3_index = [peaeson_corr1_2, peaeson_corr2_2, peaeson_corr3_2, peaeson_corr4_2]
# #         # cluster33_index = find_max_index(cluster3_index)
# #         # cluster3_ind.append(cluster33_index)
# #         # cluster4_index = [peaeson_corr1_3, peaeson_corr2_3, peaeson_corr3_3, peaeson_corr4_3]
# #         # cluster44_index = find_max_index(cluster4_index)
# #         # cluster4_ind.append(cluster44_index)
# # ##

# # ##      添加每一个聚类的情况与基线的对比情况分析
# #         ###   state1 vs baseline ##           cluster 1
# #         cluster1_index = [peaeson_corr1,peaeson_corr1_base]
# #         cluster1_base_index = find_max_index(cluster1_index)
# #         cluster1_1_base_ind.append(cluster1_base_index)
# #         ###   state2 vs baseline
# #         cluster2_index = [peaeson_corr2, peaeson_corr2_base]
# #         cluster2_base_index = find_max_index(cluster2_index)
# #         cluster2_1_base_ind.append(cluster2_base_index)
# #         #####  state3 vs baseline
# #         cluster3_index = [peaeson_corr3, peaeson_corr3_base]
# #         cluster3_base_index = find_max_index(cluster3_index)
# #         cluster3_1_base_ind.append(cluster3_base_index)
# # ########      state4 vs baseline 
# #         cluster4_index = [peaeson_corr4, peaeson_corr4_base]
# #         cluster4_base_index = find_max_index(cluster4_index)
# #         cluster4_1_base_ind.append(cluster4_base_index)
# #         ################################                           cluster 2 
# #         cluster1_1_index = [peaeson_corr1_1,peaeson_corr1_1_base]
# #         cluster1_1_base_index = find_max_index(cluster1_1_index)
# #         cluster1_1_1_base_ind.append(cluster1_1_base_index)
# #         ###   state2 vs baseline
# #         cluster2_1_index = [peaeson_corr2_1, peaeson_corr2_1_base]
# #         cluster2_1_base_index = find_max_index(cluster2_1_index)
# #         cluster2_1_1_base_ind.append(cluster2_1_base_index)
# #         #####  state3 vs baseline
# #         cluster3_1_index = [peaeson_corr3_1, peaeson_corr3_1_base]
# #         cluster3_1_base_index = find_max_index(cluster3_1_index)
# #         cluster3_1_1_base_ind.append(cluster3_1_base_index)
# # ########      state4 vs baseline 
# #         cluster4_1_index = [peaeson_corr4_1, peaeson_corr4_1_base]
# #         cluster4_1_base_index = find_max_index(cluster4_1_index)
# #         cluster4_1_1_base_ind.append(cluster4_1_base_index)        
               
# ###### cluster 1 number

# stat1_cluster1 = cluster1_1_base_ind.count(0)
# stat1_base_cluster1 = cluster1_1_base_ind.count(1)
# ##
# stat2_cluster1 = cluster2_1_base_ind.count(0)
# stat2_base_cluster1 = cluster2_1_base_ind.count(1)
# ##
# stat3_cluster1 = cluster3_1_base_ind.count(0)
# stat3_base_cluster1 = cluster3_1_base_ind.count(1)
# ##
# stat4_cluster1 = cluster4_1_base_ind.count(0)
# stat4_base_cluster1 = cluster4_1_base_ind.count(1)

# ##  cluster 2 number 
# stat1_cluster2 = cluster1_1_1_base_ind.count(0)
# stat1_base_cluster2 = cluster1_1_1_base_ind.count(1)
# ##
# stat2_cluster2 = cluster2_1_1_base_ind.count(0)
# stat2_base_cluster2 = cluster2_1_1_base_ind.count(1)
# ##
# stat3_cluster2 = cluster3_1_1_base_ind.count(0)
# stat3_base_cluster2 = cluster3_1_1_base_ind.count(1)
# ##
# stat4_cluster2 = cluster4_1_1_base_ind.count(0)
# stat4_base_cluster2 = cluster4_1_1_base_ind.count(1)
# #######   
# ## 显著性对比的结果(1)collect data for each state
# n = int(len(cluster1_1_base_ind)/100)
# state1_data = []
# state1_base = []
# ### 
# state2_data = []
# state2_base = []
# ### 
# state3_data = []
# state3_base = []
# ### 
# state4_data = []
# state4_base = []
# ###
# ########################
# state1_1data = []
# state1_1base = []
# ### 
# state2_1data = []
# state2_1base = []
# ### 
# state3_1data = []
# state3_1base = []
# ### 
# state4_1data = []
# state4_1base = []
# ############
# ### 
# # for p in range(n):
# #     sub_data1 = cluster1_1_base_ind[p*100:(p+1)*100]
# #     sub_data_1 = sub_data1.count(0)
# #     sub_data_2 = sub_data1.count(1)
# #     state1_base.append(sub_data_1)
# #     state1_data.append(sub_data_2)
# #     ##########
# #     sub_data2 = cluster2_1_base_ind[p*100:(p+1)*100]
# #     sub_data2_1 = sub_data2.count(0)
# #     sub_data2_2 = sub_data2.count(1)
# #     state2_base.append(sub_data2_1)
# #     state2_data.append(sub_data2_2)    
# #     #####
# #     sub_data3 = cluster3_1_base_ind[p*100:(p+1)*100]
# #     sub_data3_1 = sub_data3.count(0)
# #     sub_data3_2 = sub_data3.count(1)
# #     state3_base.append(sub_data3_1)
# #     state3_data.append(sub_data3_2)
# #     ###
# #     sub_data4 = cluster4_1_base_ind[p*100:(p+1)*100]
# #     sub_data4_1 = sub_data4.count(0)
# #     sub_data4_2 = sub_data4.count(1)
# #     state4_base.append(sub_data4_1)
# #     state4_data.append(sub_data4_2)  
# #     ## cluster2 ###
# #     sub_data1_clu2 = cluster1_1_1_base_ind[p*100:(p+1)*100]
# #     sub_data_1_clu2 = sub_data1_clu2.count(0)
# #     sub_data_2_clu2 = sub_data1_clu2.count(1)
# #     state1_1base.append(sub_data_1_clu2)
# #     state1_1data.append(sub_data_2_clu2)
# #     ##########
# #     sub_data2_clu2 = cluster2_1_1_base_ind[p*100:(p+1)*100]
# #     sub_data2_1_clu2 = sub_data2_clu2.count(0)
# #     sub_data2_2_clu2 = sub_data2_clu2.count(1)
# #     state2_1base.append(sub_data2_1_clu2)
# #     state2_1data.append(sub_data2_2_clu2)    
# #     #####
# #     sub_data3_clu2 = cluster3_1_1_base_ind[p*100:(p+1)*100]
# #     sub_data3_1_clu2 = sub_data3_clu2.count(0)
# #     sub_data3_2_clu2 = sub_data3_clu2.count(1)
# #     state3_1base.append(sub_data3_1_clu2)
# #     state3_1data.append(sub_data3_2_clu2)
# #     ###
# #     sub_data4_clu2 = cluster4_1_1_base_ind[p*100:(p+1)*100]
# #     sub_data4_1_clu2 = sub_data4_clu2.count(0)
# #     sub_data4_2_clu2 = sub_data4_clu2.count(1)
# #     state4_1base.append(sub_data4_1_clu2)
# #     state4_1data.append(sub_data4_2_clu2)    
    
    
# ## ttest cluster 1
# t_statistic1, p1_value = ttest_ind(state1_data,state1_base)
# t_statistic2, p2_value = ttest_ind(state2_data,state2_base)
# t_statistic3, p3_value = ttest_ind(state3_data,state3_base)
# t_statistic4, p4_value = ttest_ind(state4_data,state4_base)
# ### ttest cluster2
# t_statistic5, p5_value = ttest_ind(state1_1data,state1_1base)
# t_statistic6, p6_value = ttest_ind(state2_1data,state2_1base)
# t_statistic7, p7_value = ttest_ind(state3_1data,state3_1base)
# t_statistic8, p8_value = ttest_ind(state4_1data,state4_1base)


# Temporal_p = [p1_value,p2_value,p3_value,p4_value,p5_value,p6_value,p7_value,p8_value]

##
# fig, (ax1,ax2)= plt.subplots(1, 2, figsize = (16,12))
# ax1.bar(x1,y1,color = colors)
# ax1.set_title('Cluster1')
# ax2.bar(x1,y2,color = colors)
# ax2.set_title('Cluster2')

# x1 = ['State1','Baseline1','State2', 'Baseline2', 'State3', 'Baseline3', 'State4', 'Baseline4']
# y1 = [stat1_cluster1,stat1_base_cluster1,stat2_cluster1,stat2_base_cluster1,stat3_cluster1,stat3_base_cluster1,stat4_cluster1,stat4_base_cluster1]
# plt.bar(x1,y1,color = colors)
# plt.suptitle('Temporal_cluster1', fontsize = 16, fontweight = 'bold')
# plt.show()
# y2 = [stat1_cluster2,stat1_base_cluster2,stat2_cluster2,stat2_base_cluster2,stat3_cluster2,stat3_base_cluster2,stat4_cluster2,stat4_base_cluster2]
# plt.bar(x1,y2,color = colors)
# plt.suptitle('Temporal_cluster2', fontsize = 16, fontweight = 'bold')
# plt.show()
# ## save data 
# filename1 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal1_1clu1_base.npy'
# filename2 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal1_1clu2_base.npy'
# filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal1_1p_base.npy'
# np.save(filename1, y1)
# np.save(filename2, y2)
# np.save(filename3, Temporal_p)
#####
######################### 
## static for plot 
# # plot cluster1  about four state information
# stat1_cluster1 = cluster1_ind.count(0)
# stat2_cluster1 = cluster1_ind.count(1)
# stat3_cluster1 = cluster1_ind.count(2)
# stat4_cluster1 = cluster1_ind.count(3)
# #######333
# base_cluster1 = cluster1_ind.count(4)
# ##########33
# stat1_cluster2 = cluster2_ind.count(0)
# stat2_cluster2 = cluster2_ind.count(1)
# stat3_cluster2 = cluster2_ind.count(2)
# stat4_cluster2 = cluster2_ind.count(3)
# #######333
# base_cluster2 = cluster2_ind.count(4)
############33
# stat1_cluster3 = cluster3_ind.count(0)
# stat2_cluster3 = cluster3_ind.count(1)
# stat3_cluster3 = cluster3_ind.count(2)
# stat4_cluster3 = cluster3_ind.count(3)

# ############333
# stat1_cluster4 = cluster4_ind.count(0)
# stat2_cluster4 = cluster4_ind.count(1)
# stat3_cluster4 = cluster4_ind.count(2)
# stat4_cluster4 = cluster4_ind.count(3)
# x1 = ['State1','State2','State3','State4','Baseline']
# y1 = [stat1_cluster1,stat2_cluster1,stat3_cluster1,stat4_cluster1,base_cluster1]
# y2 = [stat1_cluster2,stat2_cluster2,stat3_cluster2,stat4_cluster2,base_cluster2]
# y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
# y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
## plot some sub-figure
# y1 = [stat1_cluster1,stat2_cluster1]
# y2 = [stat1_cluster2,stat2_cluster2]
# y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
# y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]


##
# fig, axs = plt.subplots(2, 2, figsize = (16,12))
# axs[0,0].bar(x1,y1)
# axs[0,0].set_title('Cluster1')
# axs[0,1].bar(x1,y2)
# axs[0,1].set_title('Cluster2')
# axs[1,0].bar(x1,y3)
# axs[1,0].set_title('Cluster3')
# axs[1,1].bar(x1,y4)
# axs[1,1].set_title('Cluster4')
# ######################### 添加总标题
# ###################
# plt.suptitle('Temporal', fontsize = 16, fontweight = 'bold')
# plt.show()
################# cluster 2 的 informattion
# fig, (ax1,ax2)= plt.subplots(1, 2, figsize = (16,12))
# ax1.bar(x1,y1,color = colors)
# ax1.set_title('Cluster1')
# ax2.bar(x1,y2,color = colors)
# ax2.set_title('Cluster2')

# # axs[0,0].bar(x1,y1)
# # axs[0,0].set_title('Cluster1')
# # axs[0,1].bar(x1,y2)
# # axs[0,1].set_title('Cluster2')
# # axs[1,0].bar(x1,y3)
# # axs[1,0].set_title('Cluster3')
# # axs[1,1].bar(x1,y4)
# # axs[1,1].set_title('Cluster4')
# ######################### 添加总标题
# ###################
# plt.suptitle('Temporal', fontsize = 16, fontweight = 'bold')
# plt.show()

############
##  whole de shuju fenxi 

cluster1_ind = []
cluster2_ind = []
cluster3_ind = []
cluster4_ind = []
## All subject
## fileName1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftwhole_MI1_trial.npy'
for i in range(33):
    filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'frontalright_att.npy'
    #filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeright_att.npy'
    data1 = np.load(filename)
    ###########
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeleft_att.npy'
    filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'frontalleft_att.npy'  
    # filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalleft_att.npy'
    data2= np.load(filename2)
    data = np.vstack((data1, data2))
    ####
    # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate1.npy'
    # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate2.npy'
    # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate3.npy'
    # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate4.npy'
    filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'frontalstate1.npy'
    filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'frontalstate2.npy'
    filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'frontalstate3.npy'
    filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'frontalstate4.npy'      
    # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate1.npy'
    # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate2.npy'
    # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate3.npy'
    # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate4.npy'
    state1 = np.load(filename3)
    state1_1 = state1[:,:,201:301]
    state1_2 = np.mean(state1_1, axis = 0)
    state1_3 = np.mean(state1_2, axis = 1)
    state2 = np.load(filename4)
    state2_1 = state2[:,:,201:301]
    state2_2 = np.mean(state2_1, axis = 0)
    state2_3 = np.mean(state2_2, axis = 1)
    state3 = np.load(filename5)
    state3_1 = state3[:,:,201:301]
    state3_2 = np.mean(state3_1, axis = 0)
    state3_3 = np.mean(state3_2, axis = 1)
    state4 = np.load(filename6)
    state4_1 = state4[:,:,201:301]
    state4_2 = np.mean(state4_1, axis = 0)
    state4_3 = np.mean(state4_2, axis = 1)
    ################################
    #####################
    #############
    for i in range(100):
        cluster_data = data[i,:,134:1134].T
        X = cluster_data
        km = TimeSeriesKMeans(n_clusters = 4,  metric = 'dtw', max_iter = 5, random_state=0) 
        ## 如果聚类的个数设置为2的情况下
        #km = TimeSeriesKMeans(n_clusters = 2,  metric = 'dtw', max_iter = 5, random_state=0)
        km.fit(X)
        labels = km.labels_
        centroids = km.cluster_centers_
        print(labels)
        print(centroids)
        cluster_state1 = centroids[0,:,0]
        cluster_state2 = centroids[1,:,0]
        ####
        cluster_state3 = centroids[2,:,0]
        cluster_state4 = centroids[3,:,0]
        ##  original state1
        
        peaeson_corr1, _ = pearsonr(state1_3, cluster_state1)
        peaeson_corr2, _ = pearsonr(state2_3, cluster_state1)
        peaeson_corr3, _ = pearsonr(state3_3, cluster_state1)
        peaeson_corr4, _ = pearsonr(state4_3, cluster_state1)
        ########################
        peaeson_corr1_1, _ = pearsonr(state1_3, cluster_state2)
        peaeson_corr2_1, _ = pearsonr(state2_3, cluster_state2)
        peaeson_corr3_1, _ = pearsonr(state3_3, cluster_state2)
        peaeson_corr4_1, _ = pearsonr(state4_3, cluster_state2)
        #####################
        peaeson_corr1_2, _ = pearsonr(state1_3, cluster_state3)
        peaeson_corr2_2, _ = pearsonr(state2_3, cluster_state3)
        peaeson_corr3_2, _ = pearsonr(state3_3, cluster_state3)
        peaeson_corr4_2, _ = pearsonr(state4_3, cluster_state3)
        # ###################
        peaeson_corr1_3, _ = pearsonr(state1_3, cluster_state4)
        peaeson_corr2_3, _ = pearsonr(state2_3, cluster_state4)
        peaeson_corr3_3, _ = pearsonr(state3_3, cluster_state4)
        peaeson_corr4_3, _ = pearsonr(state4_3, cluster_state4)
        ###  xuanze cluster1 according to  which state 
        ##
        cluster1_index = [peaeson_corr1, peaeson_corr2, peaeson_corr3, peaeson_corr4]
        cluster11_index = find_max_index(cluster1_index)
        cluster1_ind.append(cluster11_index)
        cluster2_index = [peaeson_corr1_1, peaeson_corr2_1, peaeson_corr3_1, peaeson_corr4_1]
        cluster22_index = find_max_index(cluster2_index)
        cluster2_ind.append(cluster22_index)
        cluster3_index = [peaeson_corr1_2, peaeson_corr2_2, peaeson_corr3_2, peaeson_corr4_2]
        cluster33_index = find_max_index(cluster3_index)
        cluster3_ind.append(cluster33_index)
        cluster4_index = [peaeson_corr1_3, peaeson_corr2_3, peaeson_corr3_3, peaeson_corr4_3]
        cluster44_index = find_max_index(cluster4_index)
        cluster4_ind.append(cluster44_index)
##
## static for plot 
# plot cluster1  about four state information
stat1_cluster1 = cluster1_ind.count(0)
stat2_cluster1 = cluster1_ind.count(1)
stat3_cluster1 = cluster1_ind.count(2)
stat4_cluster1 = cluster1_ind.count(3)

##########33
stat1_cluster2 = cluster2_ind.count(0)
stat2_cluster2 = cluster2_ind.count(1)
stat3_cluster2 = cluster2_ind.count(2)
stat4_cluster2 = cluster2_ind.count(3)

############33
stat1_cluster3 = cluster3_ind.count(0)
stat2_cluster3 = cluster3_ind.count(1)
stat3_cluster3 = cluster3_ind.count(2)
stat4_cluster3 = cluster3_ind.count(3)

# ############333
stat1_cluster4 = cluster4_ind.count(0)
stat2_cluster4 = cluster4_ind.count(1)
stat3_cluster4 = cluster4_ind.count(2)
stat4_cluster4 = cluster4_ind.count(3)
x1 = ['State1','State2','State3','State4']
y1 = [stat1_cluster1,stat2_cluster1,stat3_cluster1,stat4_cluster1]
y2 = [stat1_cluster2,stat2_cluster2,stat3_cluster2,stat4_cluster2]
y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
## plot some sub-figure
# y1 = [stat1_cluster1,stat2_cluster1]
# y2 = [stat1_cluster2,stat2_cluster2]
# y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
# y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
filename1 = '/home/lcy/MEG_attention/state/cluster/data_huitu/frontal4_clu1.npy'
filename2 = '/home/lcy/MEG_attention/state/cluster/data_huitu/frontal4_clu2.npy'
filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/frontal4_clu3.npy'
filename4 = '/home/lcy/MEG_attention/state/cluster/data_huitu/frontal4_clu4.npy'
#filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal1_1p_base.npy'
np.save(filename1, y1)
np.save(filename2, y2)
np.save(filename3, y3)
np.save(filename4, y4)
frontal_y1 = y1
frontal_y2 = y2
## save each cluster for four attention 
filename5 = '/home/lcy/MEG_attention/state/cluster/data_huitu/frontal_clu1.npy'
filename6 = '/home/lcy/MEG_attention/state/cluster/data_huitu/frontal_clu2.npy'
filename7 = '/home/lcy/MEG_attention/state/cluster/data_huitu/frontal_clu3.npy'
filename8 = '/home/lcy/MEG_attention/state/cluster/data_huitu/frontal_clu4.npy'
#############
#######
np.save(filename5, cluster1_ind)
np.save(filename6, cluster2_ind)
np.save(filename7, cluster3_ind)
np.save(filename8, cluster4_ind)

#np.save(filename3, Temporal_p)

##
# fig, axs = plt.subplots(2, 2, figsize = (16,12))
# axs[0,0].bar(x1,y1)
# axs[0,0].set_title('Cluster1')
# axs[0,1].bar(x1,y2)
# axs[0,1].set_title('Cluster2')
# axs[1,0].bar(x1,y3)
# axs[1,0].set_title('Cluster3')
# axs[1,1].bar(x1,y4)
# axs[1,1].set_title('Cluster4')
# ######################### 添加总标题
# ###################
# plt.suptitle('Temporal', fontsize = 16, fontweight = 'bold')
# plt.show()
################# cluster 2 的 informattion
fig, (ax1,ax2)= plt.subplots(1, 2, figsize = (16,12))
ax1.bar(x1,y1,color = colors)
ax1.set_title('Cluster1')
ax2.bar(x1,y2,color = colors)
ax2.set_title('Cluster2')

# axs[0,0].bar(x1,y1)
# axs[0,0].set_title('Cluster1')
# axs[0,1].bar(x1,y2)
# axs[0,1].set_title('Cluster2')
# axs[1,0].bar(x1,y3)
# axs[1,0].set_title('Cluster3')
# axs[1,1].bar(x1,y4)
# axs[1,1].set_title('Cluster4')
######################### 添加总标题
###################
plt.suptitle('Frontal', fontsize = 16, fontweight = 'bold')
plt.show()
##########################################
del y1
del y2

########## whole brain
cluster1_ind = []
cluster2_ind = []
cluster3_ind = []
cluster4_ind = []
## All subject
## fileName1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftwhole_MI1_trial.npy'
for i in range(33):
    filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/'+ 'sub'+ str('%02d' %(i+1)) + 'wholeright_att.npy'
    #filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeright_att.npy'
    data1 = np.load(filename)
    ###########
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeleft_att.npy'
    filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/'+ 'sub'+ str('%02d' %(i+1)) + 'wholeleft_att.npy'  
    # filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalleft_att.npy'
    data2= np.load(filename2)
    data = np.vstack((data1, data2))
    ####
    # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate1.npy'
    # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate2.npy'
    # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate3.npy'
    # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate4.npy'
    filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/'+ 'sub'+ str('%02d' %(i+1)) + 'wholestate1.npy'
    filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/'+ 'sub'+ str('%02d' %(i+1)) + 'wholestate2.npy'
    filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/'+ 'sub'+ str('%02d' %(i+1)) + 'wholestate3.npy'
    filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/'+ 'sub'+ str('%02d' %(i+1)) + 'wholestate4.npy'      
    # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate1.npy'
    # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate2.npy'
    # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate3.npy'
    # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate4.npy'
    state1 = np.load(filename3)
    state1_1 = state1[:,:,201:301]
    state1_2 = np.mean(state1_1, axis = 0)
    state1_3 = np.mean(state1_2, axis = 1)
    state2 = np.load(filename4)
    state2_1 = state2[:,:,201:301]
    state2_2 = np.mean(state2_1, axis = 0)
    state2_3 = np.mean(state2_2, axis = 1)
    state3 = np.load(filename5)
    state3_1 = state3[:,:,201:301]
    state3_2 = np.mean(state3_1, axis = 0)
    state3_3 = np.mean(state3_2, axis = 1)
    state4 = np.load(filename6)
    state4_1 = state4[:,:,201:301]
    state4_2 = np.mean(state4_1, axis = 0)
    state4_3 = np.mean(state4_2, axis = 1)
    ################################
    #####################
    for i in range(100):
        cluster_data = data[i,:,134:1134].T
        X = cluster_data
        km = TimeSeriesKMeans(n_clusters = 4,  metric = 'dtw', max_iter = 5, random_state=0) 
        ## 如果聚类的个数设置为2的情况下
        #km = TimeSeriesKMeans(n_clusters = 2,  metric = 'dtw', max_iter = 5, random_state=0)
        km.fit(X)
        labels = km.labels_
        centroids = km.cluster_centers_
        print(labels)
        print(centroids)
        cluster_state1 = centroids[0,:,0]
        cluster_state2 = centroids[1,:,0]
        ####
        cluster_state3 = centroids[2,:,0]
        cluster_state4 = centroids[3,:,0]
        ##  original state1
        
        peaeson_corr1, _ = pearsonr(state1_3, cluster_state1)
        peaeson_corr2, _ = pearsonr(state2_3, cluster_state1)
        peaeson_corr3, _ = pearsonr(state3_3, cluster_state1)
        peaeson_corr4, _ = pearsonr(state4_3, cluster_state1)
        ########################
        peaeson_corr1_1, _ = pearsonr(state1_3, cluster_state2)
        peaeson_corr2_1, _ = pearsonr(state2_3, cluster_state2)
        peaeson_corr3_1, _ = pearsonr(state3_3, cluster_state2)
        peaeson_corr4_1, _ = pearsonr(state4_3, cluster_state2)
        #####################
        peaeson_corr1_2, _ = pearsonr(state1_3, cluster_state3)
        peaeson_corr2_2, _ = pearsonr(state2_3, cluster_state3)
        peaeson_corr3_2, _ = pearsonr(state3_3, cluster_state3)
        peaeson_corr4_2, _ = pearsonr(state4_3, cluster_state3)
        # ###################
        peaeson_corr1_3, _ = pearsonr(state1_3, cluster_state4)
        peaeson_corr2_3, _ = pearsonr(state2_3, cluster_state4)
        peaeson_corr3_3, _ = pearsonr(state3_3, cluster_state4)
        peaeson_corr4_3, _ = pearsonr(state4_3, cluster_state4)
        ###  xuanze cluster1 according to  which state 
        ##
        cluster1_index = [peaeson_corr1, peaeson_corr2, peaeson_corr3, peaeson_corr4]
        cluster11_index = find_max_index(cluster1_index)
        cluster1_ind.append(cluster11_index)
        cluster2_index = [peaeson_corr1_1, peaeson_corr2_1, peaeson_corr3_1, peaeson_corr4_1]
        cluster22_index = find_max_index(cluster2_index)
        cluster2_ind.append(cluster22_index)
        cluster3_index = [peaeson_corr1_2, peaeson_corr2_2, peaeson_corr3_2, peaeson_corr4_2]
        cluster33_index = find_max_index(cluster3_index)
        cluster3_ind.append(cluster33_index)
        cluster4_index = [peaeson_corr1_3, peaeson_corr2_3, peaeson_corr3_3, peaeson_corr4_3]
        cluster44_index = find_max_index(cluster4_index)
        cluster4_ind.append(cluster44_index)
##
## static for plot 
# plot cluster1  about four state information
stat1_cluster1 = cluster1_ind.count(0)
stat2_cluster1 = cluster1_ind.count(1)
stat3_cluster1 = cluster1_ind.count(2)
stat4_cluster1 = cluster1_ind.count(3)

##########33
stat1_cluster2 = cluster2_ind.count(0)
stat2_cluster2 = cluster2_ind.count(1)
stat3_cluster2 = cluster2_ind.count(2)
stat4_cluster2 = cluster2_ind.count(3)

############33
stat1_cluster3 = cluster3_ind.count(0)
stat2_cluster3 = cluster3_ind.count(1)
stat3_cluster3 = cluster3_ind.count(2)
stat4_cluster3 = cluster3_ind.count(3)
#################
# ############333
stat1_cluster4 = cluster4_ind.count(0)
stat2_cluster4 = cluster4_ind.count(1)
stat3_cluster4 = cluster4_ind.count(2)
stat4_cluster4 = cluster4_ind.count(3)
##############
############################
x1 = ['State1','State2','State3','State4']
y1 = [stat1_cluster1,stat2_cluster1,stat3_cluster1,stat4_cluster1]
y2 = [stat1_cluster2,stat2_cluster2,stat3_cluster2,stat4_cluster2]
y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
## plot some sub-figure
# y1 = [stat1_cluster1,stat2_cluster1]
# y2 = [stat1_cluster2,stat2_cluster2]
# y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
# y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
filename1 = '/home/lcy/MEG_attention/state/cluster/data_huitu/whole4_clu1.npy'
filename2 = '/home/lcy/MEG_attention/state/cluster/data_huitu/whole4_clu2.npy'
filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/whole4_clu3.npy'
filename4 = '/home/lcy/MEG_attention/state/cluster/data_huitu/whole4_clu4.npy'
#filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal1_1p_base.npy'
np.save(filename1, y1)
np.save(filename2, y2)
np.save(filename3, y3)
np.save(filename4, y4)
#########
whole_y1 = y1
whole_y2 = y2
whole_y3 = y3
whole_y4 = y4
## save each cluster for four attention 
filename5 = '/home/lcy/MEG_attention/state/cluster/data_huitu/whole_clu1.npy'
filename6 = '/home/lcy/MEG_attention/state/cluster/data_huitu/whole_clu2.npy'
filename7 = '/home/lcy/MEG_attention/state/cluster/data_huitu/whole_clu3.npy'
filename8 = '/home/lcy/MEG_attention/state/cluster/data_huitu/whole_clu4.npy'
##################
np.save(filename5, cluster1_ind)
np.save(filename6, cluster2_ind)
np.save(filename7, cluster3_ind)
np.save(filename8, cluster4_ind)
#################
############
# fig, axs = plt.subplots(2, 2, figsize = (16,12))
# axs[0,0].bar(x1,y1)
# axs[0,0].set_title('Cluster1')
# axs[0,1].bar(x1,y2)
# axs[0,1].set_title('Cluster2')
# axs[1,0].bar(x1,y3)
# axs[1,0].set_title('Cluster3')
# axs[1,1].bar(x1,y4)
# axs[1,1].set_title('Cluster4')
# ######################### 添加总标题
# ###################
# plt.suptitle('Temporal', fontsize = 16, fontweight = 'bold')
# plt.show()
# ################# cluster 2 的 informattion
# fig, (ax1,ax2)= plt.subplots(1, 2, figsize = (16,12))
# ax1.bar(x1,y1,color = colors)
# ax1.set_title('Cluster1')
# ax2.bar(x1,y2,color = colors)
# ax2.set_title('Cluster2')

# # axs[0,0].bar(x1,y1)
# # axs[0,0].set_title('Cluster1')
# # axs[0,1].bar(x1,y2)
# # axs[0,1].set_title('Cluster2')
# # axs[1,0].bar(x1,y3)
# # axs[1,0].set_title('Cluster3')
# # axs[1,1].bar(x1,y4)
# # axs[1,1].set_title('Cluster4')
# ######################### 添加总标题
# ###################
# plt.suptitle('Whole', fontsize = 16, fontweight = 'bold')
# plt.show()
###################################
## occipital 的 information

cluster1_ind = []
cluster2_ind = []
cluster3_ind = []
cluster4_ind = []
## All subject
## fileName1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftwhole_MI1_trial.npy'
for i in range(33):
    filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/state/'+ 'sub'+ str('%02d' %(i+1)) + 'occipitalright_att.npy'
    #filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeright_att.npy'
    data1 = np.load(filename)
    ###########
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeleft_att.npy'
    filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/state/'+ 'sub'+ str('%02d' %(i+1)) + 'occipitalleft_att.npy'  
    # filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalleft_att.npy'
    data2= np.load(filename2)
    data = np.vstack((data1, data2))
    ####
    # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate1.npy'
    # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate2.npy'
    # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate3.npy'
    # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate4.npy'
    filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/state/'+ 'sub'+ str('%02d' %(i+1)) + 'occipitalstate1.npy'
    filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/state/'+ 'sub'+ str('%02d' %(i+1)) + 'occipitalstate2.npy'
    filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/state/'+ 'sub'+ str('%02d' %(i+1)) + 'occipitalstate3.npy'
    filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/state/'+ 'sub'+ str('%02d' %(i+1)) + 'occipitalstate4.npy'      
    # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate1.npy'
    # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate2.npy'
    # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate3.npy'
    # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate4.npy'
    state1 = np.load(filename3)
    state1_1 = state1[:,:,201:301]
    state1_2 = np.mean(state1_1, axis = 0)
    state1_3 = np.mean(state1_2, axis = 1)
    state2 = np.load(filename4)
    state2_1 = state2[:,:,201:301]
    state2_2 = np.mean(state2_1, axis = 0)
    state2_3 = np.mean(state2_2, axis = 1)
    state3 = np.load(filename5)
    state3_1 = state3[:,:,201:301]
    state3_2 = np.mean(state3_1, axis = 0)
    state3_3 = np.mean(state3_2, axis = 1)
    state4 = np.load(filename6)
    state4_1 = state4[:,:,201:301]
    state4_2 = np.mean(state4_1, axis = 0)
    state4_3 = np.mean(state4_2, axis = 1)
    ################################
    #####################
    #############
    for i in range(100):
        cluster_data = data[i,:,134:1134].T
        X = cluster_data
        km = TimeSeriesKMeans(n_clusters = 4,  metric = 'dtw', max_iter = 5, random_state=0) 
        ## 如果聚类的个数设置为2的情况下
        #km = TimeSeriesKMeans(n_clusters = 2,  metric = 'dtw', max_iter = 5, random_state=0)
        km.fit(X)
        labels = km.labels_
        centroids = km.cluster_centers_
        print(labels)
        print(centroids)
        cluster_state1 = centroids[0,:,0]
        cluster_state2 = centroids[1,:,0]
        ####
        cluster_state3 = centroids[2,:,0]
        cluster_state4 = centroids[3,:,0]
        ##  original state1
        
        peaeson_corr1, _ = pearsonr(state1_3, cluster_state1)
        peaeson_corr2, _ = pearsonr(state2_3, cluster_state1)
        peaeson_corr3, _ = pearsonr(state3_3, cluster_state1)
        peaeson_corr4, _ = pearsonr(state4_3, cluster_state1)
        ########################
        peaeson_corr1_1, _ = pearsonr(state1_3, cluster_state2)
        peaeson_corr2_1, _ = pearsonr(state2_3, cluster_state2)
        peaeson_corr3_1, _ = pearsonr(state3_3, cluster_state2)
        peaeson_corr4_1, _ = pearsonr(state4_3, cluster_state2)
        #####################
        peaeson_corr1_2, _ = pearsonr(state1_3, cluster_state3)
        peaeson_corr2_2, _ = pearsonr(state2_3, cluster_state3)
        peaeson_corr3_2, _ = pearsonr(state3_3, cluster_state3)
        peaeson_corr4_2, _ = pearsonr(state4_3, cluster_state3)
        # ###################
        peaeson_corr1_3, _ = pearsonr(state1_3, cluster_state4)
        peaeson_corr2_3, _ = pearsonr(state2_3, cluster_state4)
        peaeson_corr3_3, _ = pearsonr(state3_3, cluster_state4)
        peaeson_corr4_3, _ = pearsonr(state4_3, cluster_state4)
        ###  xuanze cluster1 according to  which state 
        ##
        cluster1_index = [peaeson_corr1, peaeson_corr2, peaeson_corr3, peaeson_corr4]
        cluster11_index = find_max_index(cluster1_index)
        cluster1_ind.append(cluster11_index)
        cluster2_index = [peaeson_corr1_1, peaeson_corr2_1, peaeson_corr3_1, peaeson_corr4_1]
        cluster22_index = find_max_index(cluster2_index)
        cluster2_ind.append(cluster22_index)
        cluster3_index = [peaeson_corr1_2, peaeson_corr2_2, peaeson_corr3_2, peaeson_corr4_2]
        cluster33_index = find_max_index(cluster3_index)
        cluster3_ind.append(cluster33_index)
        cluster4_index = [peaeson_corr1_3, peaeson_corr2_3, peaeson_corr3_3, peaeson_corr4_3]
        cluster44_index = find_max_index(cluster4_index)
        cluster4_ind.append(cluster44_index)
##
## static for plot 
# plot cluster1  about four state information
stat1_cluster1 = cluster1_ind.count(0)
stat2_cluster1 = cluster1_ind.count(1)
stat3_cluster1 = cluster1_ind.count(2)
stat4_cluster1 = cluster1_ind.count(3)

##########33
stat1_cluster2 = cluster2_ind.count(0)
stat2_cluster2 = cluster2_ind.count(1)
stat3_cluster2 = cluster2_ind.count(2)
stat4_cluster2 = cluster2_ind.count(3)

############33
stat1_cluster3 = cluster3_ind.count(0)
stat2_cluster3 = cluster3_ind.count(1)
stat3_cluster3 = cluster3_ind.count(2)
stat4_cluster3 = cluster3_ind.count(3)

# ############333
stat1_cluster4 = cluster4_ind.count(0)
stat2_cluster4 = cluster4_ind.count(1)
stat3_cluster4 = cluster4_ind.count(2)
stat4_cluster4 = cluster4_ind.count(3)
x1 = ['State1','State2','State3','State4']
y1 = [stat1_cluster1,stat2_cluster1,stat3_cluster1,stat4_cluster1]
y2 = [stat1_cluster2,stat2_cluster2,stat3_cluster2,stat4_cluster2]
y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
## plot some sub-figure
# y1 = [stat1_cluster1,stat2_cluster1]
# y2 = [stat1_cluster2,stat2_cluster2]
# y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
# y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
filename1 = '/home/lcy/MEG_attention/state/cluster/data_huitu/occipital4_clu1.npy'
filename2 = '/home/lcy/MEG_attention/state/cluster/data_huitu/occipital4_clu2.npy'
filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/occipital4_clu3.npy'
filename4 = '/home/lcy/MEG_attention/state/cluster/data_huitu/occipital4_clu4.npy'
#filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal1_1p_base.npy'
np.save(filename1, y1)
np.save(filename2, y2)
np.save(filename3, y3)
np.save(filename4, y4)
occipital_y1 = y1
occipital_y2 = y2
occipital_y3 = y3
occipital_y4 = y4
## save each cluster for four attention 
filename5 = '/home/lcy/MEG_attention/state/cluster/data_huitu/occipital_clu1.npy'
filename6 = '/home/lcy/MEG_attention/state/cluster/data_huitu/occipital_clu2.npy'
filename7 = '/home/lcy/MEG_attention/state/cluster/data_huitu/occipital_clu3.npy'
filename8= '/home/lcy/MEG_attention/state/cluster/data_huitu/occipital_clu4.npy'
np.save(filename5, cluster1_ind)
np.save(filename6, cluster2_ind)
np.save(filename7, cluster3_ind)
np.save(filename8, cluster4_ind)

##
# fig, axs = plt.subplots(2, 2, figsize = (16,12))
# axs[0,0].bar(x1,y1)
# axs[0,0].set_title('Cluster1')
# axs[0,1].bar(x1,y2)
# axs[0,1].set_title('Cluster2')
# axs[1,0].bar(x1,y3)
# axs[1,0].set_title('Cluster3')
# axs[1,1].bar(x1,y4)
# axs[1,1].set_title('Cluster4')
# ######################### 添加总标题
# ###################
# plt.suptitle('Temporal', fontsize = 16, fontweight = 'bold')
# plt.show()
################# cluster 2 的 informattion
fig, (ax1,ax2)= plt.subplots(1, 2, figsize = (16,12))
ax1.bar(x1,y1,color = colors)
ax1.set_title('Cluster1')
ax2.bar(x1,y2,color = colors)
ax2.set_title('Cluster2')

# axs[0,0].bar(x1,y1)
# axs[0,0].set_title('Cluster1')
# axs[0,1].bar(x1,y2)
# axs[0,1].set_title('Cluster2')
# axs[1,0].bar(x1,y3)
# axs[1,0].set_title('Cluster3')
# axs[1,1].bar(x1,y4)
# axs[1,1].set_title('Cluster4')
######################### 添加总标题
###################
plt.suptitle('Occipital', fontsize = 16, fontweight = 'bold')
plt.show()
########### temporal
cluster1_ind = []
cluster2_ind = []
cluster3_ind = []
cluster4_ind = []
# del y1
# del y2
## All subject
## fileName1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftwhole_MI1_trial.npy'
for i in range(33):
    filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalright_att.npy'
    #filename = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeright_att.npy'
    data1 = np.load(filename)
    ###########
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholeleft_att.npy'
    filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalleft_att.npy'  
    # filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalleft_att.npy'
    data2= np.load(filename2)
    data = np.vstack((data1, data2))
    ####
    # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate1.npy'
    # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate2.npy'
    # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate3.npy'
    # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/state/sub31wholestate4.npy'
    filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalstate1.npy'
    filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalstate2.npy'
    filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalstate3.npy'
    filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/state/'+ 'sub'+ str('%02d' %(i+1)) + 'temporalstate4.npy'      
    # filename3 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate1.npy'
    # filename4 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate2.npy'
    # filename5 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate3.npy'
    # filename6 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/sub31frontalstate4.npy'
    state1 = np.load(filename3)
    state1_1 = state1[:,:,201:301]
    state1_2 = np.mean(state1_1, axis = 0)
    state1_3 = np.mean(state1_2, axis = 1)
    state2 = np.load(filename4)
    state2_1 = state2[:,:,201:301]
    state2_2 = np.mean(state2_1, axis = 0)
    state2_3 = np.mean(state2_2, axis = 1)
    state3 = np.load(filename5)
    state3_1 = state3[:,:,201:301]
    state3_2 = np.mean(state3_1, axis = 0)
    state3_3 = np.mean(state3_2, axis = 1)
    state4 = np.load(filename6)
    state4_1 = state4[:,:,201:301]
    state4_2 = np.mean(state4_1, axis = 0)
    state4_3 = np.mean(state4_2, axis = 1)
    ################################
    #####################
    #############
    for i in range(100):
        cluster_data = data[i,:,134:1134].T
        X = cluster_data
        km = TimeSeriesKMeans(n_clusters = 4,  metric = 'dtw', max_iter = 5, random_state=0) 
        ## 如果聚类的个数设置为2的情况下
        # km = TimeSeriesKMeans(n_clusters = 2,  metric = 'dtw', max_iter = 5, random_state=0)
        km.fit(X)
        labels = km.labels_
        centroids = km.cluster_centers_
        print(labels)
        print(centroids)
        cluster_state1 = centroids[0,:,0]
        cluster_state2 = centroids[1,:,0]
        ####
        cluster_state3 = centroids[2,:,0]
        cluster_state4 = centroids[3,:,0]
        ##  original state1
        
        peaeson_corr1, _ = pearsonr(state1_3, cluster_state1)
        peaeson_corr2, _ = pearsonr(state2_3, cluster_state1)
        peaeson_corr3, _ = pearsonr(state3_3, cluster_state1)
        peaeson_corr4, _ = pearsonr(state4_3, cluster_state1)
        ########################
        peaeson_corr1_1, _ = pearsonr(state1_3, cluster_state2)
        peaeson_corr2_1, _ = pearsonr(state2_3, cluster_state2)
        peaeson_corr3_1, _ = pearsonr(state3_3, cluster_state2)
        peaeson_corr4_1, _ = pearsonr(state4_3, cluster_state2)
        #####################
        peaeson_corr1_2, _ = pearsonr(state1_3, cluster_state3)
        peaeson_corr2_2, _ = pearsonr(state2_3, cluster_state3)
        peaeson_corr3_2, _ = pearsonr(state3_3, cluster_state3)
        peaeson_corr4_2, _ = pearsonr(state4_3, cluster_state3)
        # ###################
        peaeson_corr1_3, _ = pearsonr(state1_3, cluster_state4)
        peaeson_corr2_3, _ = pearsonr(state2_3, cluster_state4)
        peaeson_corr3_3, _ = pearsonr(state3_3, cluster_state4)
        peaeson_corr4_3, _ = pearsonr(state4_3, cluster_state4)
        ###  xuanze cluster1 according to  which state 
        ##
        cluster1_index = [peaeson_corr1, peaeson_corr2, peaeson_corr3, peaeson_corr4]
        cluster11_index = find_max_index(cluster1_index)
        cluster1_ind.append(cluster11_index)
        cluster2_index = [peaeson_corr1_1, peaeson_corr2_1, peaeson_corr3_1, peaeson_corr4_1]
        cluster22_index = find_max_index(cluster2_index)
        cluster2_ind.append(cluster22_index)
        cluster3_index = [peaeson_corr1_2, peaeson_corr2_2, peaeson_corr3_2, peaeson_corr4_2]
        cluster33_index = find_max_index(cluster3_index)
        cluster3_ind.append(cluster33_index)
        cluster4_index = [peaeson_corr1_3, peaeson_corr2_3, peaeson_corr3_3, peaeson_corr4_3]
        cluster44_index = find_max_index(cluster4_index)
        cluster4_ind.append(cluster44_index)
##
## static for plot 
# plot cluster1  about four state information
stat1_cluster1 = cluster1_ind.count(0)
stat2_cluster1 = cluster1_ind.count(1)
stat3_cluster1 = cluster1_ind.count(2)
stat4_cluster1 = cluster1_ind.count(3)

##########33
stat1_cluster2 = cluster2_ind.count(0)
stat2_cluster2 = cluster2_ind.count(1)
stat3_cluster2 = cluster2_ind.count(2)
stat4_cluster2 = cluster2_ind.count(3)

############33
stat1_cluster3 = cluster3_ind.count(0)
stat2_cluster3 = cluster3_ind.count(1)
stat3_cluster3 = cluster3_ind.count(2)
stat4_cluster3 = cluster3_ind.count(3)

# ############333
stat1_cluster4 = cluster4_ind.count(0)
stat2_cluster4 = cluster4_ind.count(1)
stat3_cluster4 = cluster4_ind.count(2)
stat4_cluster4 = cluster4_ind.count(3)
x1 = ['State1','State2','State3','State4']
y1 = [stat1_cluster1,stat2_cluster1,stat3_cluster1,stat4_cluster1]
y2 = [stat1_cluster2,stat2_cluster2,stat3_cluster2,stat4_cluster2]
y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
## plot some sub-figure
# y1 = [stat1_cluster1,stat2_cluster1]
# y2 = [stat1_cluster2,stat2_cluster2]
# y3 = [stat1_cluster3,stat2_cluster3,stat3_cluster3,stat4_cluster3]
# y4 = [stat1_cluster4,stat2_cluster4,stat3_cluster4,stat4_cluster4]
filename1 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal4_clu1.npy'
filename2 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal4_clu2.npy'
filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal4_clu3.npy'
filename4 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal4_clu4.npy'
#filename3 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal1_1p_base.npy'
np.save(filename1, y1)
np.save(filename2, y2)
np.save(filename3, y3)
np.save(filename4, y4)
#####
#######
temporal_y1 = y1
temporal_y2 = y2
temporal_y3 = y3
temporal_y4 = y4
## save each cluster for four attention 
filename5 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal_clu1.npy'
filename6 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal_clu2.npy'
filename7 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal_clu3.npy'
filename8 = '/home/lcy/MEG_attention/state/cluster/data_huitu/temporal_clu4.npy'
##   
##
np.save(filename5, cluster1_ind)
np.save(filename6, cluster2_ind)
np.save(filename7, cluster3_ind)
np.save(filename8, cluster4_ind)
##
# fig, axs = plt.subplots(2, 2, figsize = (16,12))
# axs[0,0].bar(x1,y1)
# axs[0,0].set_title('Cluster1')
# axs[0,1].bar(x1,y2)
# axs[0,1].set_title('Cluster2')
# axs[1,0].bar(x1,y3)
# axs[1,0].set_title('Cluster3')
# axs[1,1].bar(x1,y4)
# axs[1,1].set_title('Cluster4')
# ######################### 添加总标题
# ###################
# plt.suptitle('Temporal', fontsize = 16, fontweight = 'bold')
# plt.show()
################# cluster 2 的 informattion
fig, (ax1,ax2)= plt.subplots(1, 2, figsize = (16,12))
ax1.bar(x1,y1,color = colors)
ax1.set_title('Cluster1')
ax2.bar(x1,y2,color = colors)
ax2.set_title('Cluster2')
###
# axs[0,0].bar(x1,y1)
# axs[0,0].set_title('Cluster1')
# axs[0,1].bar(x1,y2)
# axs[0,1].set_title('Cluster2')
# axs[1,0].bar(x1,y3)
# axs[1,0].set_title('Cluster3')
# axs[1,1].bar(x1,y4)
# axs[1,1].set_title('Cluster4')
######################### 添加总标题
###################
plt.suptitle('Temporal', fontsize = 16, fontweight = 'bold')
plt.show()























## plt.bar(x,y)

## Initialize the Kmeans object withe the number of clusters to creat
# kmeans = KMeans(n_clusters = 3)
# # Fit the Kmeans model to the data
# kmeans.fit(X)
# # Get the labels assigned to each data point
# labels = kmeans.labels_
# # Get the coordinates of the centroids
# centroids = kmeans.cluster_centers_

# ## Print the labels and centroids
# print ("Labels:",labels)
# print ("Centroids:",centroids)

# #### cluste 2 hierarchy cluster code
# from scipy.cluster.hierarchy import dendrogram, linkage
# import  numpy  as np
# import matplotlib.pyplot as plt

# ## generate some sample data
# X = np.random.rand(10,2)
# # Single linkage
# Z_single = linkage(X, method ='single')
# # Complete linkage
# Z_complete = linkage(X, method = 'complete')

# ##  plot the dendrograms
# fig, axs = plt.subplots(1,2,figsize = (10,5))
# dendrogram(Z_single, ax = axs[0])
# axs[0].set_title("Single Linkage")
# dendrogram(Z_complete, ax = axs[1])
# axs[1].set_title("Complete Linkage")
# plt.show()
# ## cluster 3  EM cluster using Gaussian Mixture Models(GMM)
# from sklearn.mixture import GaussianMixture
# import numpy as np
# import matplotlib.pyplot as plt
# # Generate some sample data
# np.random.seed(0)
# X = np.vstack([np.random.randn(100,2), np.random.randn(100,2) + np.array([5,5])])
# ## Initialize the GMM object
# gmm  = GaussianMixture(n_components = 2)
# ## fit the GMM model to the data
# gmm.fit(X)
# ## get the predicted labels and means of the Gaussian distribution
# labels = gmm.predict(X)
# means = gmm.means_
# ##
# ## plot  the data with different colors for each cluster
# colors = ['red', 'blue']
# plt.scatter(X[:,0], X[:,1], c = [colors[label] for label in labels])
# plt.scatter(means[:,0], means[:,1], marker = 'x', s = 200, linewidths = 3, color = 'black')
# plt.title ('Gaussian Mixture Model Clustering')
# plt.show()


















