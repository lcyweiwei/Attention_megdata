#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 16:18:39 2022

@author: lcy
"""
## this code is for find information structure about MI  information
## identifying oscillations by shuffling in time
import os
import yaml
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
import numpy as np
import matplotlib.pyplot as plt
import scipy
import pandas as pd
### 还有一种是检测方法是短时STFT 变换
from scipy import signal
## example f,t,Zxx = singal.stft(x,fs, nperseg = 1000) nperseg = 256



## define function
def window(x, win):
    """ Apply a window to a segment of data

    Parameters
    ----------
    x : np.ndarray
        The data
    win : np.ndarray
        The window
    Returns
    -------
    x : np.ndarray
        The windowed data
    """
    return np.multiply(win, x.T).T
## what the meaning of this window?
## define smoth (Triangular Moving Averger)
def smoothTriangle(data, degree):  
   triangle = np.concatenate((np.arange(degree +1), np.arange(degree)[::-1]))
   smoothed = []
   for i in range(degree, len(data)-degree*2):
       point = data[i:i+len(triangle)]*triangle
       smoothed.append(np.sum(point)/np.sum(triangle))
## Handle boundaries
   smoothed = [smoothed[0]]*int(degree + degree/2) + smoothed
   while len(smoothed) < len(data):
       smoothed.append(smoothed[-1])
   return smoothed
## define time_shuffled_perm (analysis_fnc, x, k_perm) %% 列出至少两种的统计方式的分析！
def time_shuffled_perm(analysis_fnc, x, k_perm):
    """
    Run a permutation test by shuffling the time-stamps of individual trials.

    Parameters
    ----------
    analysis_fnc : function
        The function that will be used to generate the spectrum
    x : np.ndarray
        The data time-series
    k_perm : int
        How many permutations to run

    Returns
    -------
    res : dict
        Dictionary of the results of the randomization analysis
        x : np.ndarray
            The raw data
        x_perm : np.ndarray
            The shuffled data
        f : np.ndarray
            The frequencies of the resulting spectrum
        y_emp : np.ndarray
            The spectrum of the empirical (unshuffled) data
        y_avg : np.ndarray
            The spectra of the shuffled permutations
        y_cis : np.ndarray
            Confidence intervals for the spectra, at the 2.5th, 95th, and
            97.5th percentile
        p : np.ndarray
            P-values (uncorrected for multiple comparisons) for each frequency
    """

    # Compute the empirical statistics
    f, y_emp = analysis_fnc(x)

    # Run a bootstrapped permutation test.
    # Create a surrogate distribution by randomly shuffling resps in time.
    x_perm = []
    y_perm = []
    x_shuff = x.copy()
    for k in range(k_perm):
        np.random.shuffle(x_shuff)
        _, y_perm_k = analysis_fnc(x_shuff)
        y_perm.append(y_perm_k)
        if k < 10:  # Keep a few permutations for illustration
            x_perm.append(x_shuff.copy())

    # Find statistically significant oscillations
    # Sometimes we get p=0 if no perms are larger than emp. Note that in this
    # case, a Bonferroni correction doesn't have any effect on the p-values.
    p = np.mean(np.vstack([y_perm, y_emp]) > y_emp, axis=0)

    # Get summary of simulated spectra
    y_avg = np.mean(y_perm, 1)
    y_cis = np.percentile(y_perm, [2.5, 95, 97.5], 1)

    # Bundle the results together
    res = {}
    res['x'] = x
    res['x_perm'] = np.array(x_perm)
    res['f'] = f
    res['y_emp'] = y_emp
    res['y_perm'] = np.array(y_perm)
    res['y_avg'] = y_avg
    res['y_cis'] = y_cis
    res['p'] = p
    return res
##  color
color = []
## my code for MI  
y1 = []
f1 = []
p1 = []
for i in range(33):
    
    filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightfrontal_MI4.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/MI1/' +'sub'+ str('%02d' %(i+1)) +'temporalleft_MI4.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightoccipital_MI4.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightwhole_MI4.npy'
    data1 = np.load(filename1)
    filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftfrontal_MI4.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/MI1//' +'sub'+ str('%02d' %(i+1)) +'temporalright_MI4.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftoccipital_MI4.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftwholeMI4.npy'
    data2 = np.load(filename2)
    x = (data1+data2)/2
    x= x[1:1000]
    ## Detrend the data 
    detrend_ord = 1
    x = sm.tsa.tsatools.detrend(x, order = detrend_ord)
    ## Window the data
    x = window(x,np.hanning(len(x)))
    ## smoth data %% Triangular Moving Averger 
    x = smoothTriangle(x, 40) ## setting degree to 10
    ##
    fs = 2000  ## Sampling rate
    nfft = 2000 ## the number of samples in the DFT
    axis = -1 ##  int, the axis of the array along which to calculate the DFT 
    y = np.abs(np.fft.fft(x,nfft,axis = axis)[:40]) ## the amplitude specture
    f = np.fft.fftfreq(nfft, 1/fs)[: 40]
    f_keep = f>0
    y1.append(y)
    f1.append(f)
    ### shuffle time for identify p
    x_perm = []
    y_perm = []
    x_shuff = x.copy()
    for k in range(5000):
        np.random.shuffle(x_shuff)
        y_perm_k = np.abs(np.fft.fft(x_shuff,nfft,axis = axis)[:40])
        #_, y_perm_k = analysis_fnc(x_shuff)
        y_perm.append(y_perm_k)
        if k < 10:  # Keep a few permutations for illustration
            x_perm.append(x_shuff.copy())
    # Find statistically significant oscillations
    # Sometimes we get p=0 if no perms are larger than emp. Note that in this
    # case, a Bonferroni correction doesn't have any effect on the p-values.
    p = np.mean(np.vstack([y_perm, y]) > y, axis=0) ## 可以在尝试一种统计方式用得到P值分析
    p1.append(p)
   
##  test for each subjects ??? 这样做是否存在一定的问题？
## plot Amplitude - Frequency 
f1 = np.mean(f1,axis = 0)
y1 = np.mean(y1, axis =0)

## huitu code
fig, ax = plt.subplots()
p1 = np.mean(p1,axis = 0)
color_rgb1 = (0/255,0/255,128/255)
ax.plot(f1, y1, color = color_rgb1, linewidth = 2.7,label = 'State 4')
ax.set_xlabel('Frequency')
ax.set_ylabel('Amplitude') 
## plt.rcParams[figure.dpi] = 300
## xianzhu xing de biaozhu
b = np.where(p1 <0.05)
b= b[0]
m = len(b)
for l in range(m):
    x1 = b[l]
    ax.plot(x1, 0.001, '*',color= 'k')
##
ax.plot(x1, 0.001, '*',color= 'k',label='p < 0.05 ')
ax.legend()
#p = time_shuffled_perm(x,100)
#ax.figure(figsize = (10,5))
plt.rcParams['savefig.dpi'] = 300
name1 = '/home/lcy/MEG_attention/oscilla/MI/shuffle/frontalMI4.tiff'
fig.savefig(name1)
### MI1
y1 = []
f1 = []
p1 = []
for i in range(33):
    #filename1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/sub02temporalMI4.npy'
    #filename1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' +'sub'+ str('%02d' %(i+1)) +'temporalright_MI4.npy'
    filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightfrontal_MI1.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/MI1//' +'sub'+ str('%02d' %(i+1)) +'temporalleft_MI1.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightoccipital_MI1.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightwhole_MI1.npy'
    data1 = np.load(filename1)
    #data1 = data1[1:1001]
    filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftfrontal_MI1.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftoccipital_MI1.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/2s/' +'sub'+ str('%02d' %(i+1)) +'slid_left_MI1s.npy'
    data2 = np.load(filename2)
    #data2 = data2[0:1001]
    x = (data1+data2)/2
    x= x[1:1001]
    ## Detrend the data 
    detrend_ord = 1
    x = sm.tsa.tsatools.detrend(x, order = detrend_ord)
    ## Window the data
    x = window(x,np.hanning(len(x)))
    ## smoth data %% Triangular Moving Averger 
    x = smoothTriangle(x, 40) ## setting degree to 10
    ##
    fs = 2000  ## Sampling rate
    nfft = 2000 ## the number of samples in the DFT
    axis = -1 ##  int, the axis of the array along which to calculate the DFT 
    y = np.abs(np.fft.fft(x,nfft,axis = axis)[:40]) ## the amplitude specture
    f = np.fft.fftfreq(nfft, 1/fs)[: 40]
    f_keep = f>0
    y1.append(y)
    f1.append(f)
    ### shuffle time for identify p
    x_perm = []
    y_perm = []
    x_shuff = x.copy()
    for k in range(5000):
        np.random.shuffle(x_shuff)
        y_perm_k = np.abs(np.fft.fft(x_shuff,nfft,axis = axis)[:40])
        #_, y_perm_k = analysis_fnc(x_shuff)
        y_perm.append(y_perm_k)
        if k < 10:  # Keep a few permutations for illustration
            x_perm.append(x_shuff.copy())
    # Find statistically significant oscillations
    # Sometimes we get p=0 if no perms are larger than emp. Note that in this
    # case, a Bonferroni correction doesn't have any effect on the p-values.
    p = np.mean(np.vstack([y_perm, y]) > y, axis=0) ## 可以在尝试一种统计方式用得到P值分析
    p1.append(p)
   
##  test for each subjects ??? 这样做是否存在一定的问题？
## plot Amplitude - Frequency 
f1 = np.mean(f1,axis = 0)
y1 = np.mean(y1, axis =0)

## huitu code
fig, ax = plt.subplots()
p1 = np.mean(p1,axis = 0)
color_rgb2 = (0/255,128/255,128/255)
ax.plot(f1, y1, color = color_rgb2, linewidth = 2.7,label = 'State 1')
#ax.plot(f1, y1, color = 'grey', linewidth = 2.7)
ax.set_xlabel('Frequency')
ax.set_ylabel('Amplitude') 
#plt.rcParams[figure.dpi] = 300
## xianzhu xing de biaozhu
b = np.where(p1 <0.05)
b= b[0]
m = len(b)
for l in range(m):
    x1 = b[l]
    ax.plot(x1, 0.001, '*',color= 'k')
##
ax.plot(x1, 0.001, '*',color= 'k',label='p < 0.05 ')
ax.legend()
#p = time_shuffled_perm(x,100)
#ax.figure(figsize = (10,5))
plt.rcParams['savefig.dpi'] = 300
name2 = '/home/lcy/MEG_attention/oscilla/MI/shuffle/frontalMI1.tiff'
fig.savefig(name2)
########3
## MI2
y1 = []
f1 = []
p1 = []
for i in range(33):
    #filename1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/sub02temporalMI4.npy'
    #filename1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' +'sub'+ str('%02d' %(i+1)) +'temporalright_MI4.npy'
    filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightfrontal_MI2.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_righttemporalMI2.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightoccipital_MI2.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightwhole_MI2.npy'
    data1 = np.load(filename1)
    filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftfrontal_MI2.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_lefttemporalMI2.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftoccipital_MI2.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftwholeMI2.npy'
    data2 = np.load(filename2)
    x = (data1+data2)/2
    x= x[1:1001]
    ## Detrend the data 
    detrend_ord = 1
    x = sm.tsa.tsatools.detrend(x, order = detrend_ord)
    ## Window the data
    x = window(x,np.hanning(len(x)))
    ## smoth data %% Triangular Moving Averger 
    x = smoothTriangle(x, 40) ## setting degree to 10
    ##
    fs = 2000  ## Sampling rate
    nfft = 2000 ## the number of samples in the DFT
    axis = -1 ##  int, the axis of the array along which to calculate the DFT 
    y = np.abs(np.fft.fft(x,nfft,axis = axis)[:40]) ## the amplitude specture
    f = np.fft.fftfreq(nfft, 1/fs)[: 40]
    f_keep = f>0
    y1.append(y)
    f1.append(f)
    ### shuffle time for identify p
    x_perm = []
    y_perm = []
    x_shuff = x.copy()
    for k in range(5000):
        np.random.shuffle(x_shuff)
        y_perm_k = np.abs(np.fft.fft(x_shuff,nfft,axis = axis)[:40])
        #_, y_perm_k = analysis_fnc(x_shuff)
        y_perm.append(y_perm_k)
        if k < 10:  # Keep a few permutations for illustration
            x_perm.append(x_shuff.copy())
    # Find statistically significant oscillations
    # Sometimes we get p=0 if no perms are larger than emp. Note that in this
    # case, a Bonferroni correction doesn't have any effect on the p-values.
    p = np.mean(np.vstack([y_perm, y]) > y, axis=0) ## 可以在尝试一种统计方式用得到P值分析
    p1.append(p)
   
##  test for each subjects ??? 这样做是否存在一定的问题？
## plot Amplitude - Frequency 
f1 = np.mean(f1,axis = 0)
y1 = np.mean(y1, axis =0)

## huitu code
fig, ax = plt.subplots()
p1 = np.mean(p1,axis = 0)
color_rgb3 = (0/255,0/255,255/255)
ax.plot(f1, y1, color = color_rgb3, linewidth = 2.7,label = 'State 2')
#ax.plot(f1, y1, color = 'grey', linewidth = 2.7)
ax.set_xlabel('Frequency')
ax.set_ylabel('Amplitude') 
#plt.rcParams[figure.dpi] = 300
## xianzhu xing de biaozhu
b = np.where(p1 <0.05)
b= b[0]
m = len(b)
for l in range(m):
    x1 = b[l]
    ax.plot(x1, 0.001, '*',color= 'k')
##
ax.plot(x1, 0.001, '*',color= 'k',label='p < 0.05 ')
ax.legend()
#p = time_shuffled_perm(x,100)
#ax.figure(figsize = (10,5))
plt.rcParams['savefig.dpi'] = 300
name3 = '/home/lcy/MEG_attention/oscilla/MI/shuffle/frontalMI2.tiff'
fig.savefig(name3)
#3##3
####### MI3
y1 = []
f1 = []
p1 = []
for i in range(33):
    #filename1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/sub02temporalMI4.npy'
    #filename1 = '/media/lcy/lcy2/preprocess/New Folder/temporal/MI/' +'sub'+ str('%02d' %(i+1)) +'temporalright_MI4.npy'
    filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftfrontal_MI3.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_lefttemporalMI3.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_leftoccipital_MI3.npy'
    #filename1 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/2s/' +'sub'+ str('%02d' %(i+1)) +'slid_left_wholeMI3s.npy'
    data1 = np.load(filename1)
    data1 = data1[1:1001]
    filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/frontal/MI//' +'sub'+ str('%02d' %(i+1)) +'slid_rightfrontalMI3.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/temporal/MI1//' +'sub'+ str('%02d' %(i+1)) +'temporalright_MI3.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/occipital/MI/4s/' +'sub'+ str('%02d' %(i+1)) +'slid_rightoccipital_MI3.npy'
    #filename2 = '/media/lcy/lcy2/MEG_attention_preprocess/New Folder/whole/MI/2s/' +'sub'+ str('%02d' %(i+1)) +'wholeright_MI3.npy'
    data2 = np.load(filename2)
    data2 = data2[0:1000]
    x = (data1+data2)/2
    x= x[1:1001]
    ## Detrend the data 
    detrend_ord = 1
    x = sm.tsa.tsatools.detrend(x, order = detrend_ord)
    ## Window the data
    x = window(x,np.hanning(len(x)))
    ## smoth data %% Triangular Moving Averger 
    x = smoothTriangle(x, 40) ## setting degree to 10
    ##
    fs = 2000  ## Sampling rate
    nfft = 2000 ## the number of samples in the DFT
    axis = -1 ##  int, the axis of the array along which to calculate the DFT 
    y = np.abs(np.fft.fft(x,nfft,axis = axis)[:40]) ## the amplitude specture
    f = np.fft.fftfreq(nfft, 1/fs)[: 40]
    f_keep = f>0
    y1.append(y)
    f1.append(f)
    ### shuffle time for identify p
    x_perm = []
    y_perm = []
    x_shuff = x.copy()
    for k in range(5000):
        np.random.shuffle(x_shuff)
        y_perm_k = np.abs(np.fft.fft(x_shuff,nfft,axis = axis)[:40])
        #_, y_perm_k = analysis_fnc(x_shuff)
        y_perm.append(y_perm_k)
        if k < 10:  # Keep a few permutations for illustration
            x_perm.append(x_shuff.copy())
    # Find statistically significant oscillations
    # Sometimes we get p=0 if no perms are larger than emp. Note that in this
    # case, a Bonferroni correction doesn't have any effect on the p-values.
    p = np.mean(np.vstack([y_perm, y]) > y, axis=0) ## 可以在尝试一种统计方式用得到P值分析
    p1.append(p)
   
##  test for each subjects ??? 这样做是否存在一定的问题？
## plot Amplitude - Frequency 
f1 = np.mean(f1,axis = 0)
y1 = np.mean(y1, axis =0)

## huitu code
fig, ax = plt.subplots()
p1 = np.mean(p1,axis = 0)
color_rgb4 = (128/255,0/255,128/255)
ax.plot(f1, y1, color = color_rgb4, linewidth = 2.7,label = 'State 3')
#ax.plot(f1, y1, color = 'grey', linewidth = 2.7)
ax.set_xlabel('Frequency')
ax.set_ylabel('Amplitude') 
#plt.rcParams[figure.dpi] = 300
## xianzhu xing de biaozhu
b = np.where(p1 <0.05)
b= b[0]
m = len(b)
for l in range(m):
    x1 = b[l]
    ax.plot(x1, 0.001, '*',color= 'k')
##
ax.plot(x1, 0.001, '*',color= 'k',label='p < 0.05 ')
ax.legend()
#p = time_shuffled_perm(x,100)
#ax.figure(figsize = (10,5))
plt.rcParams['savefig.dpi'] = 300
name4 = '/home/lcy/MEG_attention/oscilla/MI/shuffle/frontalMI3.tiff'
fig.savefig(name4)